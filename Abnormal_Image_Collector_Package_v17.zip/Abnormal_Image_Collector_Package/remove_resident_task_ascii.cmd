@echo off
cd /d "%~dp0"

set "TASK_NAME=Abnormal_Image_Watcher_Resident_SPI"

schtasks.exe /Delete /F /TN "%TASK_NAME%"

echo.
echo Scheduled task removed.
pause
