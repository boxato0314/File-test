@echo off
chcp 65001
echo ======================================
echo Build Central Report Builder EXE
echo ======================================

python -m pip install --upgrade pip
python -m pip install openpyxl pyinstaller

pyinstaller ^
  --onefile ^
  --name CentralReportBuilder ^
  --icon assets\ennostar.ico ^
  central_report_builder.py

echo.
echo Build finished.
echo EXE path: dist\CentralReportBuilder.exe
pause
