@echo off
chcp 65001
cd /d %~dp0

set WINPYTHON_ROOT=C:\Users\0904211\Tools\WinPython\WPy64-3.13.12.0
set PYTHON_EXE=%WINPYTHON_ROOT%\python\python.exe

if not exist "%PYTHON_EXE%" (
  echo 找不到 WinPython: %PYTHON_EXE%
  pause
  exit /b 1
)

"%PYTHON_EXE%" -m pip install openpyxl
"%PYTHON_EXE%" central_report_builder.py
pause
