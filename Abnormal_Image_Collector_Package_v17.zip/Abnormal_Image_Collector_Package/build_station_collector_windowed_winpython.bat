@echo off
chcp 65001
cd /d %~dp0

set WINPYTHON_ROOT=C:\Users\0904211\Tools\WinPython\WPy64-3.13.12.0
set PYTHON_EXE=%WINPYTHON_ROOT%\python\python.exe
set EXE_NAME=StationImageCollector

if not exist "%PYTHON_EXE%" (
  echo 找不到 WinPython: %PYTHON_EXE%
  pause
  exit /b 1
)

"%PYTHON_EXE%" -m pip install --upgrade pip
"%PYTHON_EXE%" -m pip install openpyxl pyinstaller

"%PYTHON_EXE%" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --name %EXE_NAME% ^
  --icon assets\ennostar.ico ^
  --hidden-import openpyxl ^
  station_image_collector.py

copy /Y station_config.json dist\%EXE_NAME%\station_config.json
copy /Y assets\ennostar.ico dist\%EXE_NAME%\.folder_icon.ico
> dist\%EXE_NAME%\desktop.ini echo [.ShellClassInfo]
>> dist\%EXE_NAME%\desktop.ini echo IconResource=.folder_icon.ico,0
attrib +s dist\%EXE_NAME%
attrib +h +s dist\%EXE_NAME%\desktop.ini
attrib +h dist\%EXE_NAME%\.folder_icon.ico

echo.
echo Build finished.
echo Output: dist\%EXE_NAME%
pause
