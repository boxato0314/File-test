@echo off
chcp 65001

echo 檢查 ImageWatcherResident.exe 是否執行中：
tasklist /FI "IMAGENAME eq ImageWatcherResident.exe"

echo.
echo 若看到 ImageWatcherResident.exe，代表背景常駐中。
pause
