import atexit
import csv
import hashlib
import json
import os
import re
import shutil
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

try:
    from openpyxl import load_workbook
except Exception as exc:
    raise RuntimeError("station_image_collector.py needs openpyxl.") from exc


LOCK_ACQUIRED = False


QUERY_COLUMNS = [
    "Request_ID",
    "Lot_No",
    "Unit_No",
    "Panel_ID",
    "X",
    "Y",
    "Defect_Found_Station",
    "Defect_Code",
    "Status",
    "Owner",
    "Remark",
]


LOG_HEADERS = [
    "Timestamp",
    "Request_ID",
    "Lot_No",
    "Unit_No",
    "Station",
    "Process_Stage",
    "Group_Type",
    "Variant",
    "Source_Bucket",
    "Result",
    "Message",
    "Match_Rule",
    "Source_Time",
    "Source_File_Name",
    "Source_Folder_Name",
    "Source_Image_Path",
    "Output_Image_Path",
]


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_text(value):
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text.lower() == "nan" else text


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def load_config():
    for name in ["station_config.json", "config.json"]:
        config_path = app_dir() / name
        if config_path.exists():
            with open(config_path, "r", encoding="utf-8-sig") as handle:
                return json.load(handle)
    raise FileNotFoundError(f"找不到 station_config.json 或 config.json: {app_dir()}")


def lock_file_path(config):
    configured = safe_text(config.get("lock_file", ""))
    if configured:
        return Path(configured)
    log_file = safe_text(config.get("log_file", ""))
    if log_file:
        return Path(log_file).with_suffix(".lock")
    return app_dir() / "collector.lock"


def recent_file(path, stale_minutes):
    item = Path(path)
    if not item.exists():
        return False
    age_sec = time.time() - item.stat().st_mtime
    return age_sec < (float(stale_minutes) * 60)


def touch_lock(config):
    if not LOCK_ACQUIRED:
        return
    path = lock_file_path(config)
    try:
        if path.exists():
            os.utime(path, None)
    except Exception:
        pass


def acquire_single_instance(config):
    global LOCK_ACQUIRED
    if not bool(config.get("single_instance", True)):
        return

    path = lock_file_path(config)
    ensure_dir(path.parent)
    stale_minutes = float(config.get("lock_stale_minutes", 30))
    status_file = config.get("status_file")

    lock_recent = recent_file(path, stale_minutes)
    status_recent = bool(status_file and recent_file(status_file, stale_minutes))
    if path.exists() and (lock_recent or status_recent):
        blocked_file = path.with_suffix(path.suffix + ".blocked.txt")
        blocked_file.write_text(
            "\n".join([
                f"Timestamp={now_str()}",
                f"Station={config.get('station', '')}",
                "Message=ALREADY_RUNNING_EXIT",
                f"ExistingLock={path}",
            ]) + "\n",
            encoding="utf-8-sig",
        )
        print(f"Another collector instance appears to be running. Lock file: {path}")
        sys.exit(0)

    path.write_text(
        "\n".join([
            f"PID={os.getpid()}",
            f"StartTime={now_str()}",
            f"Station={config.get('station', '')}",
            f"Process_Stage={config.get('process_stage', '')}",
        ]) + "\n",
        encoding="utf-8-sig",
    )
    LOCK_ACQUIRED = True


def release_single_instance(config):
    global LOCK_ACQUIRED
    if not LOCK_ACQUIRED:
        return
    path = lock_file_path(config)
    try:
        if path.exists() and f"PID={os.getpid()}" in path.read_text(encoding="utf-8-sig"):
            path.unlink()
    except Exception:
        pass
    LOCK_ACQUIRED = False


def write_status(config, message, extra=None):
    status_file = config.get("status_file") or str(app_dir() / "collector_status.txt")
    ensure_dir(Path(status_file).parent)
    lines = [
        f"Timestamp={now_str()}",
        f"Station={config.get('station', '')}",
        f"Process_Stage={config.get('process_stage', '')}",
        f"Mode={config.get('run_mode', '')}",
        f"Message={message}",
    ]
    if extra:
        for key, value in extra.items():
            lines.append(f"{key}={safe_text(value)}")
    Path(status_file).write_text("\n".join(lines) + "\n", encoding="utf-8-sig")
    touch_lock(config)


def sleep_with_heartbeat(config, interval):
    heartbeat_sec = int(config.get("status_heartbeat_sec", 60))
    heartbeat_sec = max(5, min(heartbeat_sec, interval))
    remaining = interval
    while remaining > 0:
        wait_sec = min(heartbeat_sec, remaining)
        write_status(
            config,
            "SLEEPING",
            {
                "NextScanInSec": remaining,
                "LogFile": config.get("log_file", ""),
            },
        )
        time.sleep(wait_sec)
        remaining -= wait_sec


def append_log(log_file, row):
    ensure_dir(Path(log_file).parent)
    exists = Path(log_file).exists()
    with open(log_file, "a", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=LOG_HEADERS)
        if not exists:
            writer.writeheader()
        writer.writerow({key: safe_text(row.get(key, "")) for key in LOG_HEADERS})


def archive_path(original_path, archive_dir, label):
    original = Path(original_path)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    ensure_dir(archive_dir)
    return Path(archive_dir) / f"{original.stem}_{label}_{stamp}{original.suffix}"


def rotate_file_by_size(file_path, max_mb, archive_dir, label):
    if not max_mb:
        return False
    path = Path(file_path)
    if not path.exists():
        return False
    max_bytes = float(max_mb) * 1024 * 1024
    if path.stat().st_size < max_bytes:
        return False
    target = archive_path(path, archive_dir, label)
    shutil.move(str(path), str(target))
    return True


def cleanup_part_files(config):
    hours = float(config.get("cleanup_part_files_hours", 0) or 0)
    if hours <= 0:
        return 0
    output_root = Path(config.get("output_root", ""))
    if not output_root.exists():
        return 0

    cutoff = time.time() - hours * 3600
    removed = 0
    for item in output_root.rglob("*.part"):
        try:
            if item.is_file() and item.stat().st_mtime < cutoff:
                item.unlink()
                removed += 1
        except Exception:
            pass
    return removed


def run_housekeeping(config):
    log_file = config.get("log_file", "")
    done_file = config.get("done_file", "")
    default_archive = str(Path(log_file).parent / "Archive") if log_file else str(app_dir() / "Archive")
    archive_dir = config.get("log_archive_dir", default_archive)

    rotated_log = rotate_file_by_size(log_file, config.get("log_rotate_mb", 0), archive_dir, "archive")
    rotated_done = rotate_file_by_size(done_file, config.get("max_done_record_mb", 0), archive_dir, "archive")
    removed_part = cleanup_part_files(config)
    return {
        "RotatedLog": rotated_log,
        "RotatedDoneRecord": rotated_done,
        "RemovedPartFiles": removed_part,
    }


def read_query_excel(query_file, sheet_name):
    path = Path(query_file)
    if not path.exists():
        raise FileNotFoundError(f"找不到查詢檔: {query_file}")

    workbook = load_workbook(path, data_only=True, read_only=True)
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"找不到查詢工作表: {sheet_name}")

    sheet = workbook[sheet_name]
    rows = sheet.iter_rows(values_only=True)
    headers = [safe_text(value) for value in next(rows, [])]
    index = {name: pos for pos, name in enumerate(headers)}

    query_rows = []
    for values in rows:
        item = {}
        for column in QUERY_COLUMNS:
            pos = index.get(column)
            item[column] = safe_text(values[pos]) if pos is not None and pos < len(values) else ""
        if any(item.values()):
            query_rows.append(item)
    workbook.close()
    return query_rows


def is_open(row):
    status = safe_text(row.get("Status", "")).lower()
    return status in ["", "open", "new", "待查", "查詢"]


def clean_token(value):
    return safe_text(value).lower()


def split_tokens(text):
    return [token for token in re.split(r"[^0-9a-zA-Z]+", text.lower()) if token]


def values_from_keys(row, keys):
    return [safe_text(row.get(key, "")) for key in keys if safe_text(row.get(key, ""))]


def scope_text(source_root, root, filename, scope):
    file_path = Path(root) / filename
    if scope == "full_path":
        return str(file_path)
    if scope == "relative_path":
        return str(file_path.relative_to(source_root))
    if scope == "folder_name":
        return Path(root).name
    if scope == "stem":
        return Path(filename).stem
    return filename


def match_rule(text, values, rule, option=None):
    text_raw = safe_text(text)
    text_lower = text_raw.lower()
    clean_values = [clean_token(value) for value in values if safe_text(value)]

    if rule in ["", "any", None]:
        return True
    if rule == "contains":
        return all(value in text_lower for value in clean_values)
    if rule == "token_contains":
        tokens = set(split_tokens(text_raw))
        return all(value in tokens for value in clean_values)
    if rule == "exact":
        return len(clean_values) == 1 and text_lower == clean_values[0]
    if rule == "exact_stem":
        stem = Path(text_raw).stem.lower()
        return len(clean_values) == 1 and stem == clean_values[0]
    if rule == "prefix_before_underscore":
        prefix = Path(text_raw).stem.split("_", 1)[0].lower()
        return len(clean_values) == 1 and prefix == clean_values[0]
    if rule == "stem_equals_key_plus_suffix":
        suffix = clean_token((option or {}).get("suffix", ""))
        stem = Path(text_raw).stem.lower()
        return len(clean_values) == 1 and stem == f"{clean_values[0]}{suffix}"
    if rule == "fixed_name":
        fixed_names = [name.lower() for name in (option or {}).get("fixed_names", [])]
        return Path(text_raw).name.lower() in fixed_names
    if rule == "regex":
        pattern = (option or {}).get("pattern", "")
        return bool(pattern and re.search(pattern, text_raw, flags=re.IGNORECASE))
    return False


def include_exclude_ok(target_text, include=None, exclude=None):
    lowered = target_text.lower()
    include = [safe_text(item).lower() for item in (include or []) if safe_text(item)]
    exclude = [safe_text(item).lower() for item in (exclude or []) if safe_text(item)]
    if include and not any(item in lowered for item in include):
        return False
    if exclude and any(item in lowered for item in exclude):
        return False
    return True


def condition_ok(condition, row, source_root, root, filename):
    if not condition:
        return True

    rule = condition.get("rule", "contains")
    keys = condition.get("keys", [])
    values = values_from_keys(row, keys)
    scope = condition.get("scope")

    if "fixed_names" in condition:
        rule = "fixed_name"
        scope = scope or "filename"
    if rule not in ["any", "", None] and keys and not values:
        return False

    text = scope_text(source_root, root, filename, scope or condition.get("target", "filename"))
    return match_rule(text, values, rule, condition)


def file_fingerprint(path):
    item = Path(path)
    raw = f"{item.resolve()}|{item.stat().st_size}|{item.stat().st_mtime}".encode(
        "utf-8",
        errors="ignore",
    )
    return hashlib.md5(raw).hexdigest()


def load_done_record(done_file):
    path = Path(done_file)
    if not path.exists():
        return {}

    done = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        text = line.strip()
        if not text:
            continue
        parts = text.split("\t", 1)
        done[parts[0]] = parts[1] if len(parts) > 1 else ""
    return done


def save_done_record(done_file, key, output_path):
    ensure_dir(Path(done_file).parent)
    with open(done_file, "a", encoding="utf-8-sig") as handle:
        handle.write(f"{key}\t{output_path}\n")


def done_output_exists(done, key):
    output_path = done.get(key, "")
    return bool(output_path and Path(output_path).exists())


def get_variants(group):
    variants = group.get("variants")
    if variants:
        return variants
    return [{
        "variant": group.get("variant", ""),
        "enabled": group.get("enabled", True),
        "roots": group.get("roots", []),
        "extensions": group.get("extensions", []),
        "path_include": group.get("path_include", []),
        "path_exclude": group.get("path_exclude", []),
        "filename_include": group.get("filename_include", []),
        "filename_exclude": group.get("filename_exclude", []),
        "folder_match": group.get("folder_match", {}),
        "file_match": group.get("file_match", {}),
        "match": group.get("match", {}),
        "missing_result": group.get("missing_result", "NOT_FOUND"),
        "max_matches": group.get("max_matches"),
    }]


def normalize_variant(group, variant):
    merged = dict(variant)
    for key in [
        "roots",
        "extensions",
        "path_include",
        "path_exclude",
        "filename_include",
        "filename_exclude",
        "folder_match",
        "file_match",
        "match",
        "missing_result",
        "max_matches",
        "dedupe_scope",
        "required_query_keys",
        "skip_source_search_if_output_exists",
    ]:
        if key not in merged and key in group:
            merged[key] = group[key]
    return merged


def cache_key_for_root(root_info, source_root, group, variant):
    return "|".join([
        str(source_root).lower(),
        safe_text(root_info.get("bucket", "")).lower(),
        safe_text(group.get("group_type", "")).lower(),
        safe_text(variant.get("variant", "")).lower(),
        json.dumps(root_info.get("path_include", []) + variant.get("path_include", []), ensure_ascii=False),
        json.dumps(root_info.get("path_exclude", []) + variant.get("path_exclude", []), ensure_ascii=False),
        safe_text(variant.get("max_search_depth", group.get("max_search_depth", ""))),
    ])


def folder_cache_key(row, root_info, source_root, group, variant):
    folder_match = variant.get("folder_match", {})
    keys = folder_match.get("keys", [])
    values = values_from_keys(row, keys)
    return "|".join([
        cache_key_for_root(root_info, source_root, group, variant),
        json.dumps(folder_match, ensure_ascii=False, sort_keys=True),
        json.dumps(values, ensure_ascii=False),
    ])


def folder_file_cache_key(folder, extensions):
    return "|".join([
        str(Path(folder)).lower(),
        ",".join(sorted(extensions)),
    ])


def candidate_folders_for_row(row, group, variant, root_info, source_root, max_depth, scan_cache):
    cache = scan_cache.setdefault("candidate_folders", {})
    key = folder_cache_key(row, root_info, source_root, group, variant)
    if key in cache:
        return cache[key]

    source_depth = len(source_root.parts)
    path_include = root_info.get("path_include", []) + variant.get("path_include", [])
    path_exclude = root_info.get("path_exclude", []) + variant.get("path_exclude", [])
    candidates = []

    for root, dirs, files in os.walk(source_root):
        current_depth = len(Path(root).parts) - source_depth
        if max_depth is not None and current_depth >= int(max_depth):
            dirs[:] = []

        rel_folder = str(Path(root).relative_to(source_root)) if Path(root) != source_root else ""
        if not include_exclude_ok(rel_folder, path_include, path_exclude):
            continue
        if not condition_ok(variant.get("folder_match"), row, source_root, root, ""):
            continue
        candidates.append(root)

    cache[key] = candidates
    return candidates


def cached_folder_files(folder, extensions, scan_cache):
    cache = scan_cache.setdefault("folder_files", {})
    key = folder_file_cache_key(folder, extensions)
    if key in cache:
        return cache[key]

    files = []
    try:
        for filename in os.listdir(folder):
            file_path = Path(folder) / filename
            if file_path.is_file() and file_path.suffix.lower() in extensions:
                files.append(filename)
    except Exception:
        files = []

    cache[key] = files
    return files


def cached_folder_file_index(folder, extensions, scan_cache):
    cache = scan_cache.setdefault("folder_file_index", {})
    key = folder_file_cache_key(folder, extensions)
    if key in cache:
        return cache[key]

    prefix_index = {}
    stem_index = {}
    files = cached_folder_files(folder, extensions, scan_cache)
    for filename in files:
        stem = Path(filename).stem.lower()
        prefix = stem.split("_", 1)[0]
        prefix_index.setdefault(prefix, []).append(filename)
        stem_index.setdefault(stem, []).append(filename)

    cache[key] = {
        "prefix_before_underscore": prefix_index,
        "stem": stem_index,
    }
    return cache[key]


def candidate_filenames_for_file_match(row, folder, extensions, variant, scan_cache):
    file_match = variant.get("file_match", {})
    rule = file_match.get("rule", "")
    keys = file_match.get("keys", [])
    values = values_from_keys(row, keys)
    if len(values) != 1:
        return cached_folder_files(folder, extensions, scan_cache)

    value = clean_token(values[0])
    indexes = cached_folder_file_index(folder, extensions, scan_cache)
    if rule == "prefix_before_underscore":
        return indexes["prefix_before_underscore"].get(value, [])
    if rule == "exact_stem":
        return indexes["stem"].get(value, [])
    if rule == "stem_equals_key_plus_suffix":
        suffix = clean_token(file_match.get("suffix", ""))
        return indexes["stem"].get(f"{value}{suffix}", [])
    return cached_folder_files(folder, extensions, scan_cache)


def find_matches_via_folder_cache(row, group, variant, roots, extensions, max_depth, max_matches, scan_cache):
    results = []
    for root_info in roots:
        source_root = Path(root_info["path"])
        if not source_root.exists():
            continue

        bucket = root_info.get("bucket", "")
        folders = candidate_folders_for_row(row, group, variant, root_info, source_root, max_depth, scan_cache)
        path_include = root_info.get("path_include", []) + variant.get("path_include", [])
        path_exclude = root_info.get("path_exclude", []) + variant.get("path_exclude", [])

        for folder in folders:
            for filename in candidate_filenames_for_file_match(row, folder, extensions, variant, scan_cache):
                file_path = Path(folder) / filename
                relative_text = str(file_path.relative_to(source_root))
                if not include_exclude_ok(relative_text, path_include, path_exclude):
                    continue
                if not include_exclude_ok(filename, variant.get("filename_include", []), variant.get("filename_exclude", [])):
                    continue
                if not condition_ok(variant.get("file_match"), row, source_root, folder, filename):
                    continue
                if not condition_ok(variant.get("match"), row, source_root, folder, filename):
                    continue

                results.append({
                    "source_path": str(file_path),
                    "source_root": str(source_root),
                    "source_bucket": bucket,
                    "source_file_name": file_path.name,
                    "source_folder_name": Path(folder).name,
                    "match_rule": json.dumps({
                        "folder_match": variant.get("folder_match", {}),
                        "file_match": variant.get("file_match", {}),
                        "match": variant.get("match", {}),
                        "filename_include": variant.get("filename_include", []),
                        "search_mode": "folder_cache",
                    }, ensure_ascii=False),
                })
                if max_matches and len(results) >= int(max_matches):
                    return results
    return results


def dedupe_scope(group, variant):
    return safe_text(variant.get("dedupe_scope") or group.get("dedupe_scope") or "unit").lower()


def required_query_keys(group, variant):
    if "required_query_keys" in variant:
        return variant.get("required_query_keys") or []
    if "required_query_keys" in group:
        return group.get("required_query_keys") or []
    if dedupe_scope(group, variant) == "lot":
        return ["Lot_No"]
    return ["Lot_No", "Unit_No"]


def missing_query_keys(row, group, variant):
    return [key for key in required_query_keys(group, variant) if not safe_text(row.get(key, ""))]


def identity_parts(row, config, group, variant, include_unit=True):
    parts = [
        row.get("Lot_No", ""),
        config.get("station", ""),
        group.get("group_type", ""),
        variant.get("variant", ""),
    ]
    if include_unit and dedupe_scope(group, variant) != "lot":
        parts.insert(1, row.get("Unit_No", ""))
    return [sanitize_part(part).lower() for part in parts if safe_text(part)]


def find_matches(row, group, variant, scan_cache=None):
    scan_cache = scan_cache if scan_cache is not None else {}
    results = []
    roots = sorted(variant.get("roots", []), key=lambda item: int(item.get("priority", 999)))
    extensions = set(ext.lower() for ext in variant.get("extensions", [".jpg", ".jpeg", ".png", ".bmp", ".tif", ".tiff"]))
    max_depth = variant.get("max_search_depth", group.get("max_search_depth"))
    max_matches = variant.get("max_matches", group.get("max_matches"))

    if variant.get("folder_match") and variant.get("file_match"):
        return find_matches_via_folder_cache(row, group, variant, roots, extensions, max_depth, max_matches, scan_cache)

    for root_info in roots:
        source_root = Path(root_info["path"])
        if not source_root.exists():
            continue

        bucket = root_info.get("bucket", "")
        source_depth = len(source_root.parts)
        root_path_include = root_info.get("path_include", []) + variant.get("path_include", [])
        root_path_exclude = root_info.get("path_exclude", []) + variant.get("path_exclude", [])

        for root, dirs, files in os.walk(source_root):
            if max_depth is not None:
                current_depth = len(Path(root).parts) - source_depth
                if current_depth >= int(max_depth):
                    dirs[:] = []

            for filename in files:
                file_path = Path(root) / filename
                if file_path.suffix.lower() not in extensions:
                    continue

                relative_text = str(file_path.relative_to(source_root))
                if not include_exclude_ok(relative_text, root_path_include, root_path_exclude):
                    continue
                if not include_exclude_ok(filename, variant.get("filename_include", []), variant.get("filename_exclude", [])):
                    continue

                if not condition_ok(variant.get("folder_match"), row, source_root, root, filename):
                    continue
                if not condition_ok(variant.get("file_match"), row, source_root, root, filename):
                    continue
                if not condition_ok(variant.get("match"), row, source_root, root, filename):
                    continue

                results.append({
                    "source_path": str(file_path),
                    "source_root": str(source_root),
                    "source_bucket": bucket,
                    "source_file_name": file_path.name,
                    "source_folder_name": Path(root).name,
                    "match_rule": json.dumps({
                        "folder_match": variant.get("folder_match", {}),
                        "file_match": variant.get("file_match", {}),
                        "match": variant.get("match", {}),
                        "filename_include": variant.get("filename_include", []),
                    }, ensure_ascii=False),
                })
                if max_matches and len(results) >= int(max_matches):
                    return results
    return results


def source_time(path):
    text = str(path)
    matches = re.findall(r"(20\d{12})", text)
    if matches:
        return matches[-1]
    date_matches = re.findall(r"(20\d{6})", text)
    if date_matches:
        return date_matches[-1]
    return datetime.fromtimestamp(Path(path).stat().st_mtime).strftime("%Y%m%d%H%M%S")


def sanitize_part(value):
    text = safe_text(value)
    text = re.sub(r'[<>:"/\\|?*]+', "_", text)
    text = re.sub(r"\s+", "_", text)
    return text.strip("._ ")


def render_template(template, values):
    rendered = template
    for key, value in values.items():
        rendered = rendered.replace("{" + key + "}", sanitize_part(value))
    rendered = re.sub(r"_{2,}", "_", rendered)
    rendered = rendered.replace("_NA_", "_").replace("_None_", "_")
    return rendered.strip("_ ")


def output_path_for(config, row, group, variant, match):
    station = config.get("station", "")
    group_type = group.get("group_type", "")
    variant_name = variant.get("variant", "")
    source_path = Path(match["source_path"])
    src_time = source_time(source_path)

    values = {
        "Request_ID": row.get("Request_ID", ""),
        "Lot_No": row.get("Lot_No", "UNKNOWN_LOT") or "UNKNOWN_LOT",
        "Unit_No": "LOT" if dedupe_scope(group, variant) == "lot" else (row.get("Unit_No", "UNKNOWN_UNIT") or "UNKNOWN_UNIT"),
        "Station": station,
        "Group_Type": group_type,
        "Variant": variant_name,
        "Source_Bucket": match.get("source_bucket", ""),
        "SourceTime": src_time,
        "OriginalName": source_path.name,
    }

    layout = config.get("output_layout", {})
    folder_template = layout.get("folder_template", "{Lot_No}/{Station}")
    filename_template = layout.get(
        "filename_template",
        "{Lot_No}_{Unit_No}_{Station}_{Group_Type}_{Variant}_{Source_Bucket}_{SourceTime}_{OriginalName}",
    )

    folder_rel = render_template(folder_template, values)
    filename = render_template(filename_template, values)
    if not Path(filename).suffix:
        filename += source_path.suffix
    return Path(config["output_root"]) / folder_rel / filename, src_time


def output_folder_for_precheck(config, row, group, variant):
    values = {
        "Request_ID": row.get("Request_ID", ""),
        "Lot_No": row.get("Lot_No", "UNKNOWN_LOT") or "UNKNOWN_LOT",
        "Unit_No": "LOT" if dedupe_scope(group, variant) == "lot" else (row.get("Unit_No", "UNKNOWN_UNIT") or "UNKNOWN_UNIT"),
        "Station": config.get("station", ""),
        "Group_Type": group.get("group_type", ""),
        "Variant": variant.get("variant", ""),
        "Source_Bucket": "",
        "SourceTime": "",
        "OriginalName": "",
    }
    layout = config.get("output_layout", {})
    folder_template = layout.get("folder_template", "{Lot_No}/{Station}")
    return Path(config["output_root"]) / render_template(folder_template, values)


def output_precheck_enabled(config, group, variant):
    if bool(config.get("force_recheck_source", False)):
        return False
    if "skip_source_search_if_output_exists" in variant:
        return bool(variant.get("skip_source_search_if_output_exists"))
    if "skip_source_search_if_output_exists" in group:
        return bool(group.get("skip_source_search_if_output_exists"))
    return bool(config.get("skip_source_search_if_output_exists", False))


def valid_output_exists(config, row, group, variant):
    if not output_precheck_enabled(config, group, variant):
        return False

    folder = output_folder_for_precheck(config, row, group, variant)
    if not folder.exists():
        return False

    min_size = int(config.get("output_exists_min_size_bytes", 1))
    criteria = identity_parts(row, config, group, variant, include_unit=True)

    for file_path in folder.rglob("*"):
        if not file_path.is_file():
            continue
        if file_path.name.lower().endswith(".part"):
            continue
        try:
            if file_path.stat().st_size < min_size:
                continue
        except Exception:
            continue
        filename = file_path.name.lower()
        if all(item in filename for item in criteria):
            return True
    return False


def copy_match(config, row, group, variant, match, done):
    station = config.get("station", "")
    group_type = group.get("group_type", "")
    variant_name = variant.get("variant", "")
    source_path = Path(match["source_path"])
    fingerprint = file_fingerprint(source_path)
    done_key = "|".join([
        *identity_parts(row, config, group, variant, include_unit=True),
        safe_text(match.get("source_bucket", "")),
        fingerprint,
    ])

    if bool(config.get("skip_duplicate", True)) and done_output_exists(done, done_key):
        return None

    target, src_time = output_path_for(config, row, group, variant, match)
    ensure_dir(target.parent)
    temp_target = target.with_name(target.name + ".part")
    if temp_target.exists():
        temp_target.unlink()

    shutil.copy2(source_path, temp_target)
    temp_target.replace(target)
    save_done_record(config["done_file"], done_key, str(target))
    return str(target), src_time


def base_log(config, row, group, variant):
    return {
        "Timestamp": now_str(),
        "Request_ID": row.get("Request_ID", ""),
        "Lot_No": row.get("Lot_No", ""),
        "Unit_No": row.get("Unit_No", ""),
        "Station": config.get("station", ""),
        "Process_Stage": config.get("process_stage", ""),
        "Group_Type": group.get("group_type", ""),
        "Variant": variant.get("variant", ""),
    }


def run_once(config):
    housekeeping = run_housekeeping(config)
    query_rows = read_query_excel(config["query_file"], config.get("query_sheet_name", "Query_Input"))
    done = load_done_record(config["done_file"])
    log_file = config["log_file"]
    scan_cache = {
        "candidate_folders": {},
        "folder_files": {},
        "folder_file_index": {},
    }
    max_source_searches = int(
        config.get(
            "max_source_searches_per_scan",
            config.get("max_open_rows_per_scan", 0),
        ) or 0
    )

    summary = {
        "TotalRows": 0,
        "OpenRowsSeen": 0,
        "GroupsChecked": 0,
        "SourceSearches": 0,
        "Found": 0,
        "NotFound": 0,
        "Copied": 0,
        "DuplicateSkipped": 0,
        "OutputExistsSkipped": 0,
        "Disabled": 0,
        "SkippedMissingQueryKey": 0,
        "Errors": 0,
        "LimitReached": 0,
        "FolderCacheEntries": 0,
        "FolderFileCacheEntries": 0,
        "FolderFileIndexEntries": 0,
        **housekeeping,
    }

    for row in query_rows:
        if not is_open(row):
            continue

        summary["OpenRowsSeen"] += 1
        summary["TotalRows"] += 1
        touch_lock(config)

        for group in config.get("image_groups", []):
            if not group.get("enabled", True):
                summary["Disabled"] += 1
                continue

            for raw_variant in get_variants(group):
                variant = normalize_variant(group, raw_variant)
                if not variant.get("enabled", True):
                    summary["Disabled"] += 1
                    continue

                summary["GroupsChecked"] += 1
                try:
                    touch_lock(config)
                    missing_keys = missing_query_keys(row, group, variant)
                    if missing_keys:
                        summary["SkippedMissingQueryKey"] += 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Result": "SKIP_MISSING_QUERY_KEY",
                            "Message": ",".join(missing_keys),
                        })
                        continue

                    if valid_output_exists(config, row, group, variant):
                        summary["OutputExistsSkipped"] += 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Result": "OUTPUT_EXISTS_SKIP",
                            "Message": "Valid output image already exists; skipped source search.",
                        })
                        continue

                    if max_source_searches and summary["SourceSearches"] >= max_source_searches:
                        summary["LimitReached"] = 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Result": "SCAN_LIMIT_DEFERRED",
                            "Message": "Deferred because max_source_searches_per_scan was reached.",
                        })
                        continue

                    roots = variant.get("roots", [])
                    if not roots:
                        summary["Errors"] += 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Result": "CONFIG_NO_ROOT",
                            "Message": "No roots configured for this group/variant.",
                        })
                        continue

                    existing_roots = [root for root in roots if Path(root.get("path", "")).exists()]
                    if not existing_roots:
                        summary["Errors"] += 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Result": "SOURCE_ROOT_MISSING",
                            "Message": ";".join(root.get("path", "") for root in roots),
                        })
                        continue

                    summary["SourceSearches"] += 1
                    matches = find_matches(row, group, variant, scan_cache)
                    if not matches:
                        summary["NotFound"] += 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Result": variant.get("missing_result", "NOT_FOUND"),
                            "Message": "No matched image.",
                        })
                        continue

                    copied_any = False
                    for match in matches:
                        copied = copy_match(config, row, group, variant, match, done)
                        if copied is None:
                            summary["DuplicateSkipped"] += 1
                            append_log(log_file, {
                                **base_log(config, row, group, variant),
                                "Source_Bucket": match.get("source_bucket", ""),
                                "Result": "FOUND_DUPLICATE_SKIP",
                                "Message": "Matched image exists in done_record and output path still exists.",
                                "Match_Rule": match.get("match_rule", ""),
                                "Source_Time": source_time(match["source_path"]),
                                "Source_File_Name": match.get("source_file_name", ""),
                                "Source_Folder_Name": match.get("source_folder_name", ""),
                                "Source_Image_Path": match.get("source_path", ""),
                            })
                            continue

                        output_path, src_time = copied
                        copied_any = True
                        summary["Copied"] += 1
                        append_log(log_file, {
                            **base_log(config, row, group, variant),
                            "Source_Bucket": match.get("source_bucket", ""),
                            "Result": "FOUND",
                            "Message": "Copied image.",
                            "Match_Rule": match.get("match_rule", ""),
                            "Source_Time": src_time,
                            "Source_File_Name": match.get("source_file_name", ""),
                            "Source_Folder_Name": match.get("source_folder_name", ""),
                            "Source_Image_Path": match.get("source_path", ""),
                            "Output_Image_Path": output_path,
                        })

                    if copied_any or matches:
                        summary["Found"] += 1
                except Exception as exc:
                    summary["Errors"] += 1
                    append_log(log_file, {
                        **base_log(config, row, group, variant),
                        "Result": "ERROR",
                        "Message": str(exc),
                    })

    summary["FolderCacheEntries"] = len(scan_cache.get("candidate_folders", {}))
    summary["FolderFileCacheEntries"] = len(scan_cache.get("folder_files", {}))
    summary["FolderFileIndexEntries"] = len(scan_cache.get("folder_file_index", {}))
    write_status(config, "RUN_ONCE_OK", summary)
    print(f"[{now_str()}] Station={config.get('station','')}, {summary}")


def main():
    config = load_config()
    acquire_single_instance(config)
    atexit.register(release_single_instance, config)
    interval = int(config.get("scan_interval_sec", 300))
    run_mode = config.get("run_mode", "loop").lower()

    print("======================================")
    print(" Station Image Collector")
    print("======================================")
    print(f"APP DIR : {app_dir()}")
    print(f"STATION : {config.get('station', '')}")
    print(f"MODE    : {run_mode}")
    print("Press Ctrl+C to stop.")
    print("")
    write_status(config, "STARTED", {"AppDir": app_dir()})

    if run_mode == "once":
        try:
            run_once(config)
        finally:
            release_single_instance(config)
        return

    while True:
        try:
            write_status(config, "LOOP_START", {"LogFile": config.get("log_file", "")})
            run_once(config)
        except Exception:
            error = traceback.format_exc()
            print(error)
            write_status(config, "PROGRAM_ERROR", {"Error": error})
            try:
                append_log(config["log_file"], {
                    "Timestamp": now_str(),
                    "Station": config.get("station", ""),
                    "Process_Stage": config.get("process_stage", ""),
                    "Result": "PROGRAM_ERROR",
                    "Message": error,
                })
            except Exception:
                pass
        sleep_with_heartbeat(config, interval)


if __name__ == "__main__":
    main()
