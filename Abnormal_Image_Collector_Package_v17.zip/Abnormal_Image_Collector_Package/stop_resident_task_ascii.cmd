@echo off
cd /d "%~dp0"

set "TASK_NAME=Abnormal_Image_Watcher_Resident_SPI"

schtasks.exe /End /TN "%TASK_NAME%"

echo.
echo Stop command sent.
pause
