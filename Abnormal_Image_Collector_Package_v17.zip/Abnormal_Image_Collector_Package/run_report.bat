@echo off
chcp 65001
cd /d %~dp0
python central_report_builder.py
pause
