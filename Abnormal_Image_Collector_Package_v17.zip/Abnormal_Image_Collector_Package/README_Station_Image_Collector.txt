# Station Image Collector 部署說明

## 目的
此版本是新版機台端部署程式，使用同一支 station_image_collector.py，
透過 station_config.json 切換 SPI2 / AOI3 / AOI4 / 3DL / FT1 的搜尋規則。

## 查詢主題
所有站點統一使用：
- Lot_No
- Unit_No

Unit_No 即 LED NO.。各站點只是在自己的資料夾與檔名規則中尋找同一個查詢主題。

## 已支援站點範例
- station_config_SPI2_example.json
- station_config_AOI3_example.json
- station_config_AOI4_example.json
- station_config_3DL_example.json
- station_config_FT1_example.json

正式部署時，將其中一份複製為 station_config.json，修改路徑後打包。

## 建議輸出結構
Output/{Lot_No}/{Station}/

分類資訊放在檔名與 log 中，例如：
{Lot_No}_{Unit_No}_{Station}_{Group_Type}_{Variant}_{Source_Bucket}_{SourceTime}_{OriginalName}

## 網路中斷保護
複製檔案時會先寫成 .part 暫存檔，完成後才改成正式檔名。
done_record 會記錄 source fingerprint 與 output path。
下一輪只有在 output path 仍存在時才跳過，因此若雲端或網路磁碟檔案遺失，會自動補傳。

## 背景常駐保護
新版 config 預設：
  "single_instance": true

若同站點背景程式已在執行，第二個程式會直接退出，避免重複掃描與重複寫檔。

## 資源保護
新版 config 預設：
  "max_source_searches_per_scan": 50
  "skip_source_search_if_output_exists": true

每輪最多執行 50 次來源資料夾搜尋。
若 Output 已存在同一 Lot + Unit + Station + Group + Variant 的有效檔案，會跳過來源資料夾搜尋。
已經 Output exists 的項目不計入 50 次上限，所以長清單仍會往後掃。
若要強制重查來源，將：
  "force_recheck_source": true

## by lot / by unit
新版 config 支援：
  "dedupe_scope": "lot"
  "dedupe_scope": "unit"

整版圖、Map、FT1 等 by lot 圖種只需要 Lot_No，Unit_No 可空白。
元件圖 by unit 圖種需要 Lot_No + Unit_No，若 Unit_No 空白會記錄 SKIP_MISSING_QUERY_KEY 並跳過。

目前預設：
  SPI2 COMPONENT = unit
  SPI2 BOARD / HEATMAP = lot
  AOI3/AOI4 COMPONENT = unit
  AOI3/AOI4 BOARD = lot
  3DL COMPONENT_2D / COMPONENT_3D = unit
  3DL DEFECT_MAP = lot
  FT1 BOARD H_DEFECTMAP / Mapping_H = lot

## Housekeeping
新版 config 預設：
  "log_rotate_mb": 20
  "cleanup_part_files_hours": 24
  "max_done_record_mb": 50

collector_log.csv 超過大小會封存到 Archive。
超過指定時間的 .part 暫存檔會清理。
done_record 過大時會封存；若 Output pre-check 開啟，已存在的 Output 仍會跳過來源搜尋。

## Jupyter 打包
建議使用：
BUILD_STATION_COLLECTOR_WITH_JUPYTER.ipynb

修改 CONFIG_EXAMPLE 後逐格執行。
第一次測試會用 run_mode=once。
打包前 notebook 會自動改成 run_mode=loop。

## 啟動確認
不要依賴 tasklist/schtasks。
請看 station_config.json 裡的 status_file，例如：
F:/Abnormal_Image_Project_Test/Log/SPI2_collector_status.txt

若 Timestamp 持續更新，代表常駐程式正在運行。
