﻿# 異常圖片彙整 - Windows Image Watcher 部署說明

## 目的
設備端不能安裝 Python 時，可先在工程師電腦打包成 ImageWatcher.exe。
設備端只需複製 EXE、config.json、run.bat 即可執行。

## 設備端需要的檔案
- ImageWatcher.exe
- config.json
- run.bat

## 開發/打包端需要的檔案
- image_watcher.py
- config.json
- build_exe.bat

## 打包步驟
1. 在可安裝 Python 的工程師電腦放置 image_watcher.py 與 build_exe.bat
2. 執行 build_exe.bat
3. 產生 dist/ImageWatcher.exe
4. 將 ImageWatcher.exe 複製到設備端

## 設備端使用方式
1. 建立資料夾，例如 D:\ImageWatcher_SPI
2. 放入 ImageWatcher.exe、config.json、run.bat
3. 修改 config.json：
   - station
   - query_file
   - source_image_root
   - output_root
   - log_file
   - match_mode
4. 執行 run.bat

## 建議 config.json 範例
- SPI:
  station = SPI
  source_image_root = E:/SPI_Image
  log_file = D:/Abnormal_Image_Project/Log/SPI_log.csv

- AOI3:
  station = AOI3
  source_image_root = E:/AOI3_Image
  log_file = D:/Abnormal_Image_Project/Log/AOI3_log.csv

- AOI4:
  station = AOI4
  source_image_root = E:/AOI4_Image
  log_file = D:/Abnormal_Image_Project/Log/AOI4_log.csv

- Tilt:
  station = Tilt
  source_image_root = E:/Tilt_Image
  log_file = D:/Abnormal_Image_Project/Log/Tilt_log.csv

## match_mode
- lot_unit：用 Lot_No + Unit_No 查圖
- lot_panel_xy：用 Lot_No + Panel_ID + X + Y 查圖
- lot_panel：用 Lot_No + Panel_ID 查圖
- lot_only：只用 Lot_No 查圖，容易抓到太多圖片

## 注意事項
1. 設備端不需要安裝 Python。
2. 若公司防毒攔截 PyInstaller EXE，需請 IT 將 ImageWatcher.exe 加入白名單。
3. 若雲端同步不穩，建議改用 NAS 中繼資料夾，再由辦公室電腦同步雲端。
4. 若圖片資料夾很大，建議限制 max_search_depth 或建立 index 機制。