Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
appDir = fso.GetParentFolderName(WScript.ScriptFullName)
exePath = appDir & "\ImageWatcherResident.exe"
shell.CurrentDirectory = appDir
shell.Run """" & exePath & """", 0, False
