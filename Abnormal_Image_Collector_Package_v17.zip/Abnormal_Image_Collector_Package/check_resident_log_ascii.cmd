@echo off
cd /d "%~dp0"

echo Latest SPI log lines:
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "if (Test-Path 'F:\Abnormal_Image_Project_Test\Log\SPI_log.csv') { Get-Content 'F:\Abnormal_Image_Project_Test\Log\SPI_log.csv' -Tail 5 } else { Write-Host 'SPI_log.csv not found' }"

echo.
pause
