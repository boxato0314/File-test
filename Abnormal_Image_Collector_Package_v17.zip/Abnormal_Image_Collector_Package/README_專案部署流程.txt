# 異常圖片彙整專案 - 部署流程

## 新版機台端收圖程式
若要部署 SPI2 / AOI3 / AOI4 / 3DL / FT1，建議使用新版：
- station_image_collector.py
- station_config_{站點}_example.json
- BUILD_STATION_COLLECTOR_WITH_JUPYTER.ipynb
- README_Station_Image_Collector.txt
- README_station_config_詳細說明.txt

新版支援：
- 每站點多種 image group / variant
- 資料夾與檔名分開比對
- OK/NG 或不同 bucket 多來源搜尋
- Output/{Lot_No}/{Station}/ 簡化輸出
- .part 安全複製與網路中斷補傳
- status_file 背景運行確認

## 目標
Tilt 發現異常後，只要把要追查的批號/顆號放進共用或雲端同步資料夾的 query_list.xlsx，
SPI、AOI3、AOI4、Tilt 各自設備端會搜尋本機圖片，並把符合條件的圖片複製到共用輸出資料夾。
中央端最後執行 central_report_builder.py，產出 Excel 彙整報表。

## 建議資料夾
D:/Abnormal_Image_Project/
  Query_Input/query_list.xlsx
  Output/{Lot_No}/{Request_ID}/{Station}/
  Log/Tilt_log.csv
  Log/SPI_log.csv
  Log/AOI3_log.csv
  Log/AOI4_log.csv
  Report/abnormal_image_summary.xlsx

若設備不能直接使用雲端同步資料夾，建議改用共同 NAS 位置，再由辦公室電腦同步雲端。

## 查詢 Excel 欄位
工作表名稱：Query_Input

必要欄位：
- Request_ID：每筆追查唯一編號，例如 TILT_20260623_001
- Lot_No：批號
- Unit_No：顆號
- Panel_ID：Panel 或載板識別
- X / Y：座標
- Defect_Found_Station：通常填 Tilt
- Defect_Code：異常代碼
- Status：Open / New / 待查 / 查詢 才會被機台端處理

建議欄位：
- Owner：負責人
- Remark：備註

## 機台端部署
每一站各放一份：
- ImageWatcher.exe
- config.json
- run.bat

各站 config.json 必改欄位：
- station：Tilt / SPI / AOI3 / AOI4
- query_file：共同 query_list.xlsx 位置
- source_image_root：該設備本機圖片根目錄
- output_root：共同 Output 位置
- log_file：該站 log CSV 位置
- done_file：該站去重紀錄位置
- match_mode：依設備檔名規則選 lot_unit / lot_panel_xy / lot_panel / lot_only
- match_scope：依設備資料夾結構選 filename / folder_name / relative_path / full_path

## match_mode 與 match_scope
match_mode 決定用哪些欄位當關鍵字：
- lot_unit：用 Lot_No + Unit_No 查圖
- lot_panel_xy：用 Lot_No + Panel_ID + X + Y 查圖
- lot_panel：用 Lot_No + Panel_ID 查圖
- lot_only：只用 Lot_No 查圖，容易抓到太多圖片

match_scope 決定比對哪一段路徑：
- filename：只比對圖片檔名，例如 7878_1.jpg
- folder_name：只比對圖片所在資料夾名稱
- relative_path：比對 source_image_root 以下的相對路徑
- full_path：比對完整路徑

SPI Photo/NG 範例：
  F:/Photo/NG/202606/20260623162908_NONE_A326689B94300913_NONE_CE03-0702_A5SPI002_NONE_1/7878_1.jpg

此結構的有效資訊多在資料夾名稱，不在圖片檔名，因此建議：
  source_image_root = F:/Photo/NG
  match_scope = relative_path
  max_search_depth = 4

若 query_list.xlsx 的 Lot_No 是 A326689B94300913，Unit_No 是 7878，match_mode 可用 lot_unit。
若 Unit_No 不會出現在 SPI 路徑或檔名，請改用 lot_only 或依設備實際命名規則調整查詢欄位。

## 中央端彙整
1. 修改 report_config.json 的 query_file、output_file、station_logs。
2. 若中央電腦使用 WinPython，已確認可用路徑：
   C:/Users/0904211/Tools/WinPython/WPy64-3.13.12.0/python/python.exe
3. WinPython 方式直接執行：
   run_report_winpython.bat
4. 一般 Python 方式執行：
   python central_report_builder.py
5. 產生 abnormal_image_summary.xlsx。

## 使用 WinPython 打包 EXE
若設備端不能直接安裝 Python，可在有 WinPython 的工程師電腦打包。

建議先用輕量常駐版打包，因為它只依賴 openpyxl，不依賴 pandas，成功率較高。

輕量常駐版 ImageWatcherResident：
  build_resident_onedir_winpython.bat

輸出資料夾：
  dist/ImageWatcherResident/

部署到機台時複製整個 ImageWatcherResident 資料夾，修改裡面的 config.json，再執行 ImageWatcherResident.exe。

若要避免使用者關閉黑色視窗，請改用背景排程：
1. 將下列檔案複製到 dist/ImageWatcherResident/：
   start_resident_hidden.vbs
   install_resident_task.bat
   start_resident_task_now.bat
   stop_resident_task.bat
   remove_resident_task.bat
   check_resident_process.bat
2. 確認 config.json 的 run_mode 是 loop。
3. 執行 install_resident_task.bat 建立登入後自動背景啟動。
4. 執行 start_resident_task_now.bat 立刻背景啟動。
5. 執行 check_resident_process.bat 確認 ImageWatcherResident.exe 是否在背景執行。
6. 需要停止時執行 stop_resident_task.bat。

若 .bat 出現亂碼、指令缺字或一閃即滅，請改用純 ASCII 版本：
  install_resident_task_ascii.cmd
  start_resident_task_now_ascii.cmd
  check_resident_process_ascii.cmd
  check_resident_log_ascii.cmd
  stop_resident_task_ascii.cmd
  remove_resident_task_ascii.cmd

若公司電腦限制 tasklist/schtasks，建議改用無黑窗 Python 常駐版：
1. 使用 BUILD_WINDOWED_RESIDENT_WITH_JUPYTER.ipynb 打包。
2. 打包參數會使用 --windowed，因此不會顯示黑色 console 視窗。
3. config.json 加入 status_file，例如：
   "status_file": "F:/Abnormal_Image_Project_Test/Log/SPI_watcher_status.txt"
4. 確認運行方式：打開 status_file，看 Timestamp 是否持續更新。

機台端 ImageWatcher.exe：
  build_exe_winpython.bat

中央端 CentralReportBuilder.exe：
  build_report_exe_winpython.bat

打包前 bat 會使用：
  C:/Users/0904211/Tools/WinPython/WPy64-3.13.12.0/python/python.exe

## 現場驗證建議
1. 先放 1 筆 Request_ID 測試，確認四站 log 都有新增紀錄。
2. 檢查 Output/{Lot_No}/{Request_ID}/{Station}/ 是否產生圖片。
3. 執行中央彙整，確認 Summary 內四站狀態是否為 FOUND / NOT_FOUND / ERROR。
4. 若某站一直 NOT_FOUND，優先確認 match_mode 與設備圖片檔名是否真的包含對應欄位。

## 重要限制
目前 image_watcher.py 是用檔名關鍵字搜尋，不會解析設備資料庫。
如果圖片檔名沒有批號/顆號/Panel/XY，就需要另外建立圖片索引表，或依設備實際資料夾規則客製搜尋邏輯。

## 斷線與重傳機制
新版 watcher 會先將圖片複製成 .part 暫存檔，完成後才改成正式圖片檔。

done_record 會記錄：
  Request_ID + Station + Source fingerprint + Output path

下一輪掃描時，只有在 Output path 仍然存在時才會跳過。
因此若網路磁碟或雲端同步過程中檔案遺失、或你手動刪除已上傳圖片，下一輪會重新補傳。

注意：
1. 舊版 done_record 沒有 Output path，新版會視為需要重新確認並補傳。
2. 若複製到一半斷線，可能留下 .part 檔；下一輪會刪除舊 .part 並重新複製。
3. 若圖片已完整複製且 Output path 存在，則不會重複上傳。
