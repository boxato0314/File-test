@echo off
cd /d "%~dp0"

set "TASK_NAME=Abnormal_Image_Watcher_Resident_SPI"

schtasks.exe /Run /TN "%TASK_NAME%"

echo.
echo Start command sent.
echo Run check_resident_process_ascii.cmd to verify.
pause
