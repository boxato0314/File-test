﻿import os
import sys
import time
import json
import shutil
import hashlib
import traceback
from pathlib import Path
from datetime import datetime

try:
    import pandas as pd
except Exception:
    pd = None


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_text(value):
    if value is None:
        return ""
    s = str(value).strip()
    if s.lower() == "nan":
        return ""
    return s


def load_config():
    config_path = app_dir() / "config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"找不到設定檔: {config_path}")
    with open(config_path, "r", encoding="utf-8-sig") as f:
        return json.load(f)


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def csv_escape(value):
    s = safe_text(value)
    if any(ch in s for ch in [",", '"', "\n", "\r"]):
        s = '"' + s.replace('"', '""') + '"'
    return s


def append_log(log_file, row):
    ensure_dir(Path(log_file).parent)
    headers = [
        "Timestamp", "Station", "Request_ID", "Lot_No", "Unit_No", "Panel_ID",
        "X", "Y", "Match_Mode", "Keywords", "Result", "Message",
        "Source_Image_Path", "Output_Image_Path"
    ]
    exists = Path(log_file).exists()
    with open(log_file, "a", encoding="utf-8-sig", newline="") as f:
        if not exists:
            f.write(",".join(headers) + "\n")
        f.write(",".join(csv_escape(row.get(h, "")) for h in headers) + "\n")


def read_query_excel(query_file, sheet_name):
    if pd is None:
        raise RuntimeError("此版本需要 pandas/openpyxl。請使用 PyInstaller 打包版，不要直接用裸 Python 執行。")

    path = Path(query_file)
    if not path.exists():
        raise FileNotFoundError(f"找不到查詢檔: {query_file}")

    df = pd.read_excel(path, sheet_name=sheet_name, dtype=str).fillna("")

    required = [
        "Request_ID", "Lot_No", "Unit_No", "Panel_ID", "X", "Y",
        "Defect_Found_Station", "Defect_Code", "Status"
    ]
    for col in required:
        if col not in df.columns:
            df[col] = ""
    return df


def is_open(row):
    status = safe_text(row.get("Status", "")).lower()
    return status in ["", "open", "new", "待查", "查詢"]


def build_keywords(row, match_mode):
    lot = safe_text(row.get("Lot_No", ""))
    unit = safe_text(row.get("Unit_No", ""))
    panel = safe_text(row.get("Panel_ID", ""))
    x = safe_text(row.get("X", ""))
    y = safe_text(row.get("Y", ""))

    if match_mode == "lot_unit":
        return [lot, unit]
    if match_mode == "lot_panel_xy":
        return [lot, panel, x, y]
    if match_mode == "lot_panel":
        return [lot, panel]
    if match_mode == "lot_only":
        return [lot]

    return [lot, unit]


def file_fingerprint(path):
    p = Path(path)
    raw = f"{p.resolve()}|{p.stat().st_size}|{p.stat().st_mtime}".encode("utf-8", errors="ignore")
    return hashlib.md5(raw).hexdigest()


def load_done_record(done_file):
    p = Path(done_file)
    if not p.exists():
        return {}

    done = {}
    for line in p.read_text(encoding="utf-8-sig").splitlines():
        text = line.strip()
        if not text:
            continue
        parts = text.split("\t", 1)
        key = parts[0]
        output_path = parts[1] if len(parts) > 1 else ""
        done[key] = output_path
    return done


def save_done_record(done_file, key, output_path):
    ensure_dir(Path(done_file).parent)
    with open(done_file, "a", encoding="utf-8-sig") as f:
        f.write(f"{key}\t{output_path}\n")


def done_output_exists(done, key):
    output_path = done.get(key, "")
    return bool(output_path and Path(output_path).exists())


def searchable_text(source, root, filename, match_scope):
    file_path = Path(root) / filename
    if match_scope == "full_path":
        return str(file_path).lower()
    if match_scope == "relative_path":
        return str(file_path.relative_to(source)).lower()
    if match_scope == "folder_name":
        return Path(root).name.lower()
    return filename.lower()


def find_images(source_root, keywords, extensions, max_depth=None, match_scope="filename"):
    source = Path(source_root)
    if not source.exists():
        raise FileNotFoundError(f"找不到圖片來源資料夾: {source_root}")

    keywords = [k.lower() for k in keywords if safe_text(k)]
    if not keywords:
        return []

    exts = set(e.lower() for e in extensions)
    results = []

    source_depth = len(source.parts)

    for root, dirs, files in os.walk(source):
        if max_depth is not None:
            current_depth = len(Path(root).parts) - source_depth
            if current_depth >= int(max_depth):
                dirs[:] = []

        for name in files:
            ext = Path(name).suffix.lower()
            if ext not in exts:
                continue

            target_text = searchable_text(source, root, name, match_scope)

            if all(k in target_text for k in keywords):
                results.append(str(Path(root) / name))

    return results


def copy_images(images, output_root, station, row, done_file, skip_duplicate=True):
    lot = safe_text(row.get("Lot_No", "UNKNOWN_LOT"))
    unit = safe_text(row.get("Unit_No", "UNKNOWN_UNIT"))
    request_id = safe_text(row.get("Request_ID", "UNKNOWN_REQUEST"))

    target_dir = Path(output_root) / lot / request_id / station
    ensure_dir(target_dir)

    done = load_done_record(done_file) if skip_duplicate else set()
    copied = []

    for img in images:
        fp = file_fingerprint(img)
        done_key = f"{request_id}|{station}|{fp}"
        if skip_duplicate and done_output_exists(done, done_key):
            continue

        src = Path(img)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        new_name = f"{lot}_{unit}_{station}_{request_id}_{timestamp}_{src.name}"
        dst = target_dir / new_name
        temp_dst = dst.with_name(dst.name + ".part")
        if temp_dst.exists():
            temp_dst.unlink()

        shutil.copy2(src, temp_dst)
        temp_dst.replace(dst)
        copied.append((str(src), str(dst)))

        if skip_duplicate:
            save_done_record(done_file, done_key, str(dst))

    return copied


def run_once(config):
    station = config["station"]
    query_file = config["query_file"]
    sheet_name = config.get("query_sheet_name", "Query_Input")
    source_root = config["source_image_root"]
    output_root = config["output_root"]
    log_file = config["log_file"]
    done_file = config.get("done_file", str(app_dir() / "done_record.txt"))
    match_mode = config.get("match_mode", "lot_unit")
    extensions = config.get("image_extensions", [".jpg", ".jpeg", ".png", ".bmp"])
    max_depth = config.get("max_search_depth", None)
    match_scope = config.get("match_scope", "filename")
    skip_duplicate = bool(config.get("skip_duplicate", True))

    df = read_query_excel(query_file, sheet_name)

    total = 0
    found = 0
    not_found = 0
    copied_count = 0

    for _, row in df.iterrows():
        if not is_open(row):
            continue

        total += 1

        request_id = safe_text(row.get("Request_ID", ""))
        lot = safe_text(row.get("Lot_No", ""))
        unit = safe_text(row.get("Unit_No", ""))
        panel = safe_text(row.get("Panel_ID", ""))
        x = safe_text(row.get("X", ""))
        y = safe_text(row.get("Y", ""))

        keywords = build_keywords(row, match_mode)

        try:
            images = find_images(source_root, keywords, extensions, max_depth=max_depth, match_scope=match_scope)
            if images:
                copied = copy_images(images, output_root, station, row, done_file, skip_duplicate)
                found += 1
                copied_count += len(copied)

                if copied:
                    for src, dst in copied:
                        append_log(log_file, {
                            "Timestamp": now_str(),
                            "Station": station,
                            "Request_ID": request_id,
                            "Lot_No": lot,
                            "Unit_No": unit,
                            "Panel_ID": panel,
                            "X": x,
                            "Y": y,
                            "Match_Mode": match_mode,
                            "Keywords": "|".join(keywords),
                            "Result": "FOUND",
                            "Message": f"Copied 1 image. Total matched={len(images)}",
                            "Source_Image_Path": src,
                            "Output_Image_Path": dst
                        })
                else:
                    append_log(log_file, {
                        "Timestamp": now_str(),
                        "Station": station,
                        "Request_ID": request_id,
                        "Lot_No": lot,
                        "Unit_No": unit,
                        "Panel_ID": panel,
                        "X": x,
                        "Y": y,
                        "Match_Mode": match_mode,
                        "Keywords": "|".join(keywords),
                        "Result": "FOUND_DUPLICATE_SKIP",
                        "Message": f"Matched {len(images)} image(s), but already copied before.",
                        "Source_Image_Path": ";".join(images),
                        "Output_Image_Path": ""
                    })
            else:
                not_found += 1
                append_log(log_file, {
                    "Timestamp": now_str(),
                    "Station": station,
                    "Request_ID": request_id,
                    "Lot_No": lot,
                    "Unit_No": unit,
                    "Panel_ID": panel,
                    "X": x,
                    "Y": y,
                    "Match_Mode": match_mode,
                    "Keywords": "|".join(keywords),
                    "Result": "NOT_FOUND",
                    "Message": "No matched image.",
                    "Source_Image_Path": "",
                    "Output_Image_Path": ""
                })

        except Exception as e:
            append_log(log_file, {
                "Timestamp": now_str(),
                "Station": station,
                "Request_ID": request_id,
                "Lot_No": lot,
                "Unit_No": unit,
                "Panel_ID": panel,
                "X": x,
                "Y": y,
                "Match_Mode": match_mode,
                "Keywords": "|".join(keywords),
                "Result": "ERROR",
                "Message": str(e),
                "Source_Image_Path": "",
                "Output_Image_Path": ""
            })

    print(f"[{now_str()}] Station={station}, Total={total}, Found={found}, NotFound={not_found}, Copied={copied_count}")


def main():
    config = load_config()
    interval = int(config.get("scan_interval_sec", 300))
    run_mode = config.get("run_mode", "loop").lower()

    print("======================================")
    print(" Abnormal Image Watcher")
    print("======================================")
    print(f"APP DIR : {app_dir()}")
    print(f"STATION : {config.get('station', '')}")
    print(f"MODE    : {run_mode}")
    print("Press Ctrl+C to stop.")
    print("")

    if run_mode == "once":
        run_once(config)
        return

    while True:
        try:
            run_once(config)
        except Exception:
            err = traceback.format_exc()
            print(err)
            try:
                append_log(config["log_file"], {
                    "Timestamp": now_str(),
                    "Station": config.get("station", ""),
                    "Result": "PROGRAM_ERROR",
                    "Message": err
                })
            except Exception:
                pass

        time.sleep(interval)


if __name__ == "__main__":
    main()
