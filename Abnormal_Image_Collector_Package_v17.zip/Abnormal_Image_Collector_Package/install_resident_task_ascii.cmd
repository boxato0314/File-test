@echo off
cd /d "%~dp0"

set "TASK_NAME=Abnormal_Image_Watcher_Resident_SPI"
set "START_SCRIPT=%~dp0start_resident_hidden.vbs"

if not exist "%~dp0ImageWatcherResident.exe" (
  echo ImageWatcherResident.exe not found.
  echo Run this file inside the dist\ImageWatcherResident folder.
  pause
  exit /b 1
)

if not exist "%START_SCRIPT%" (
  echo start_resident_hidden.vbs not found.
  pause
  exit /b 1
)

echo Creating scheduled task: %TASK_NAME%
echo Start script: %START_SCRIPT%

schtasks.exe /Create /F /SC ONLOGON /TN "%TASK_NAME%" /TR "wscript.exe \"%START_SCRIPT%\""

echo.
echo Done. The task will start after Windows logon.
echo To start now, run start_resident_task_now_ascii.cmd
pause
