﻿@echo off
chcp 65001
set TASK_NAME=Abnormal_Image_Watcher_SPI
schtasks /Delete /F /TN "%TASK_NAME%"
echo 已移除排程工作：%TASK_NAME%
pause