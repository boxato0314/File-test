@echo off
chcp 65001
cd /d %~dp0

set WINPYTHON_ROOT=C:\Users\0904211\Tools\WinPython\WPy64-3.13.12.0
set PYTHON_EXE=%WINPYTHON_ROOT%\python\python.exe

if not exist "%PYTHON_EXE%" (
  echo 找不到 WinPython: %PYTHON_EXE%
  pause
  exit /b 1
)

echo ======================================
echo Build ImageWatcherResident windowed EXE
echo ======================================
echo Python: %PYTHON_EXE%

"%PYTHON_EXE%" -m pip install --upgrade pip
"%PYTHON_EXE%" -m pip install openpyxl pyinstaller

if exist build rmdir /s /q build
if exist dist\ImageWatcherResidentWindowed rmdir /s /q dist\ImageWatcherResidentWindowed

"%PYTHON_EXE%" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --windowed ^
  --name ImageWatcherResidentWindowed ^
  --icon assets\ennostar.ico ^
  --hidden-import openpyxl ^
  image_watcher_resident.py

if errorlevel 1 (
  echo.
  echo Build failed. 請把畫面錯誤訊息貼給 Codex。
  pause
  exit /b 1
)

copy /Y config_resident_windowed_example.json dist\ImageWatcherResidentWindowed\config.json
copy /Y assets\ennostar.ico dist\ImageWatcherResidentWindowed\.folder_icon.ico
> dist\ImageWatcherResidentWindowed\desktop.ini echo [.ShellClassInfo]
>> dist\ImageWatcherResidentWindowed\desktop.ini echo IconResource=.folder_icon.ico,0
attrib +s dist\ImageWatcherResidentWindowed
attrib +h +s dist\ImageWatcherResidentWindowed\desktop.ini
attrib +h dist\ImageWatcherResidentWindowed\.folder_icon.ico

echo.
echo Build finished.
echo Windowed resident folder:
echo %cd%\dist\ImageWatcherResidentWindowed
echo.
echo 執行 ImageWatcherResidentWindowed.exe 後不會顯示黑色視窗。
echo 請看 watcher_status.txt 或 Log CSV 確認是否運行。
pause
