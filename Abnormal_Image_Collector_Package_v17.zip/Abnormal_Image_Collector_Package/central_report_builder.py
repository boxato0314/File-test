import csv
import json
from collections import defaultdict
from datetime import datetime
from pathlib import Path

try:
    from openpyxl import Workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter
except Exception as exc:
    raise RuntimeError(
        "central_report_builder.py needs openpyxl. Install it on the central PC, "
        "or build this script as an EXE with PyInstaller."
    ) from exc


STATIONS = ["Tilt", "SPI", "AOI3", "AOI4"]


QUERY_COLUMNS = [
    "Request_ID",
    "Lot_No",
    "Unit_No",
    "Panel_ID",
    "X",
    "Y",
    "Defect_Found_Station",
    "Defect_Code",
    "Status",
    "Owner",
    "Remark",
]


def safe_text(value):
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text.lower() == "nan" else text


def load_config():
    config_path = Path(__file__).resolve().parent / "report_config.json"
    with open(config_path, "r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def read_csv_rows(path):
    if not Path(path).exists():
        return []
    with open(path, "r", encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def read_query_input(path, sheet_name):
    try:
        from openpyxl import load_workbook
    except Exception as exc:
        raise RuntimeError("Reading query_list.xlsx needs openpyxl.") from exc

    workbook = load_workbook(path, data_only=True)
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"Query sheet not found: {sheet_name}")
    sheet = workbook[sheet_name]

    headers = [safe_text(cell.value) for cell in sheet[1]]
    index = {name: pos for pos, name in enumerate(headers)}
    rows = []
    for row in sheet.iter_rows(min_row=2, values_only=True):
        item = {}
        for col in QUERY_COLUMNS:
            pos = index.get(col)
            item[col] = safe_text(row[pos]) if pos is not None and pos < len(row) else ""
        if any(item.values()):
            rows.append(item)
    return rows


def summarize_station_logs(station_logs):
    summary = defaultdict(lambda: defaultdict(lambda: {
        "result": "NO_LOG",
        "count": 0,
        "first_output": "",
        "latest_time": "",
        "message": "",
    }))

    priority = {
        "FOUND": 4,
        "FOUND_DUPLICATE_SKIP": 3,
        "NOT_FOUND": 2,
        "ERROR": 1,
        "NO_LOG": 0,
    }

    for station, log_path in station_logs.items():
        for row in read_csv_rows(log_path):
            request_id = safe_text(row.get("Request_ID"))
            if not request_id:
                continue

            result = safe_text(row.get("Result")) or "NO_LOG"
            bucket = summary[request_id][station]
            bucket["count"] += 1 if result in ["FOUND", "FOUND_DUPLICATE_SKIP"] else 0

            if priority.get(result, 0) >= priority.get(bucket["result"], 0):
                bucket["result"] = result
                bucket["message"] = safe_text(row.get("Message"))

            output_path = safe_text(row.get("Output_Image_Path"))
            if output_path and not bucket["first_output"]:
                bucket["first_output"] = output_path

            timestamp = safe_text(row.get("Timestamp"))
            if timestamp > bucket["latest_time"]:
                bucket["latest_time"] = timestamp

    return summary


def overall_status(station_summary):
    states = [station_summary[station]["result"] for station in STATIONS]
    if all(state == "FOUND" or state == "FOUND_DUPLICATE_SKIP" for state in states):
        return "COMPLETE"
    if any(state == "ERROR" for state in states):
        return "HAS_ERROR"
    if any(state == "FOUND" or state == "FOUND_DUPLICATE_SKIP" for state in states):
        return "PARTIAL"
    if any(state == "NOT_FOUND" for state in states):
        return "NOT_FOUND"
    return "NO_LOG"


def add_headers(sheet, headers):
    sheet.append(headers)
    fill = PatternFill("solid", fgColor="1F4E78")
    for cell in sheet[1]:
        cell.font = Font(color="FFFFFF", bold=True)
        cell.fill = fill
        cell.alignment = Alignment(horizontal="center", vertical="center")
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = sheet.dimensions


def write_report(output_path, query_rows, station_summary, station_logs):
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = "Summary"

    headers = [
        "Request_ID",
        "Lot_No",
        "Unit_No",
        "Panel_ID",
        "X",
        "Y",
        "Defect_Found_Station",
        "Defect_Code",
        "Overall_Status",
    ]
    for station in STATIONS:
        headers.extend([
            f"{station}_Result",
            f"{station}_Image_Count",
            f"{station}_First_Image",
            f"{station}_Latest_Time",
            f"{station}_Message",
        ])
    headers.extend(["Owner", "Remark"])
    add_headers(sheet, headers)

    fills = {
        "COMPLETE": "C6EFCE",
        "PARTIAL": "FFEB9C",
        "HAS_ERROR": "FFC7CE",
        "NOT_FOUND": "F4B084",
        "NO_LOG": "D9EAD3",
    }

    for item in query_rows:
        request_id = safe_text(item.get("Request_ID"))
        station_data = station_summary[request_id]
        row = [
            request_id,
            safe_text(item.get("Lot_No")),
            safe_text(item.get("Unit_No")),
            safe_text(item.get("Panel_ID")),
            safe_text(item.get("X")),
            safe_text(item.get("Y")),
            safe_text(item.get("Defect_Found_Station")),
            safe_text(item.get("Defect_Code")),
            overall_status(station_data),
        ]
        link_columns = []
        for station in STATIONS:
            data = station_data[station]
            row.extend([
                data["result"],
                data["count"],
                data["first_output"],
                data["latest_time"],
                data["message"],
            ])
            link_columns.append(len(row) - 2)
        row.extend([safe_text(item.get("Owner")), safe_text(item.get("Remark"))])
        sheet.append(row)
        current_row = sheet.max_row

        status_cell = sheet.cell(current_row, 9)
        status_cell.fill = PatternFill("solid", fgColor=fills.get(status_cell.value, "FFFFFF"))

        for col in link_columns:
            cell = sheet.cell(current_row, col)
            if cell.value:
                cell.hyperlink = cell.value
                cell.style = "Hyperlink"

    for column in sheet.columns:
        max_len = max(len(safe_text(cell.value)) for cell in column)
        width = min(max(max_len + 2, 12), 45)
        sheet.column_dimensions[get_column_letter(column[0].column)].width = width

    for row in sheet.iter_rows():
        for cell in row:
            cell.alignment = Alignment(vertical="top", wrap_text=True)

    detail = workbook.create_sheet("Station_Log_Detail")
    detail_headers = [
        "Station", "Timestamp", "Request_ID", "Lot_No", "Unit_No", "Panel_ID",
        "X", "Y", "Result", "Message", "Source_Image_Path", "Output_Image_Path",
    ]
    add_headers(detail, detail_headers)
    for station in STATIONS:
        for row in read_csv_rows(station_logs.get(station, "")):
            detail.append([
                station,
                safe_text(row.get("Timestamp")),
                safe_text(row.get("Request_ID")),
                safe_text(row.get("Lot_No")),
                safe_text(row.get("Unit_No")),
                safe_text(row.get("Panel_ID")),
                safe_text(row.get("X")),
                safe_text(row.get("Y")),
                safe_text(row.get("Result")),
                safe_text(row.get("Message")),
                safe_text(row.get("Source_Image_Path")),
                safe_text(row.get("Output_Image_Path")),
            ])

    for column in detail.columns:
        max_len = max(len(safe_text(cell.value)) for cell in column)
        width = min(max(max_len + 2, 12), 55)
        detail.column_dimensions[get_column_letter(column[0].column)].width = width

    workbook.save(output_path)


def main():
    config = load_config()
    query_file = config["query_file"]
    query_sheet = config.get("query_sheet_name", "Query_Input")
    station_logs = config["station_logs"]
    output_file = config.get("output_file")
    if not output_file:
        stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_file = str(Path(query_file).resolve().parent / f"abnormal_image_summary_{stamp}.xlsx")

    query_rows = read_query_input(query_file, query_sheet)
    summary = summarize_station_logs(station_logs)
    Path(output_file).resolve().parent.mkdir(parents=True, exist_ok=True)
    write_report(output_file, query_rows, summary, station_logs)
    print(f"Report created: {output_file}")


if __name__ == "__main__":
    main()
