@echo off
chcp 65001
cd /d %~dp0

set TASK_NAME=Abnormal_Image_Watcher_Resident_SPI
set START_SCRIPT=%~dp0start_resident_hidden.vbs

if not exist "%~dp0ImageWatcherResident.exe" (
  echo 找不到 ImageWatcherResident.exe
  echo 請在 dist\ImageWatcherResident 資料夾內執行此批次檔。
  pause
  exit /b 1
)

if not exist "%START_SCRIPT%" (
  echo 找不到 start_resident_hidden.vbs
  pause
  exit /b 1
)

echo 建立 Windows 背景排程工作：%TASK_NAME%
echo 啟動腳本：%START_SCRIPT%

schtasks /Create /F /SC ONLOGON /TN "%TASK_NAME%" /TR "wscript.exe \"%START_SCRIPT%\""

echo.
echo 已建立。下次登入 Windows 時會背景啟動。
echo 若要現在立刻背景啟動，請執行 start_resident_task_now.bat
pause
