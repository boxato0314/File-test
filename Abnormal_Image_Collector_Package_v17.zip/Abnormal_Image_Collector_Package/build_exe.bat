﻿@echo off
chcp 65001
echo ======================================
echo Build Abnormal Image Watcher EXE
echo ======================================

python -m pip install --upgrade pip
python -m pip install pandas openpyxl pyinstaller

pyinstaller ^
  --onefile ^
  --name ImageWatcher ^
  --icon assets\ennostar.ico ^
  --hidden-import openpyxl ^
  --hidden-import pandas ^
  image_watcher.py

echo.
echo Build finished.
echo EXE path: dist\ImageWatcher.exe
pause
