@echo off
chcp 65001
cd /d %~dp0

set TASK_NAME=Abnormal_Image_Watcher_Resident_SPI

schtasks /Run /TN "%TASK_NAME%"

echo.
echo 已要求排程背景啟動。
echo 可用 check_resident_process.bat 確認是否正在執行。
pause
