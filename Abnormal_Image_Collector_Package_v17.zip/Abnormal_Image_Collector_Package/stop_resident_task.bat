@echo off
chcp 65001

set TASK_NAME=Abnormal_Image_Watcher_Resident_SPI

schtasks /End /TN "%TASK_NAME%"

echo.
echo 已要求停止排程工作。
pause
