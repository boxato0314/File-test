@echo off
chcp 65001
cd /d %~dp0

set WINPYTHON_ROOT=C:\Users\0904211\Tools\WinPython\WPy64-3.13.12.0
set PYTHON_EXE=%WINPYTHON_ROOT%\python\python.exe

if not exist "%PYTHON_EXE%" (
  echo 找不到 WinPython: %PYTHON_EXE%
  pause
  exit /b 1
)

echo ======================================
echo Build ImageWatcherResident onedir EXE
echo ======================================
echo Python: %PYTHON_EXE%

"%PYTHON_EXE%" -m pip install --upgrade pip
"%PYTHON_EXE%" -m pip install openpyxl pyinstaller

if exist build rmdir /s /q build
if exist dist\ImageWatcherResident rmdir /s /q dist\ImageWatcherResident

"%PYTHON_EXE%" -m PyInstaller ^
  --noconfirm ^
  --clean ^
  --onedir ^
  --name ImageWatcherResident ^
  --icon assets\ennostar.ico ^
  --hidden-import openpyxl ^
  image_watcher_resident.py

if errorlevel 1 (
  echo.
  echo Build failed. 請把畫面錯誤訊息貼給 Codex。
  pause
  exit /b 1
)

copy /Y config_resident_example.json dist\ImageWatcherResident\config.json
copy /Y assets\ennostar.ico dist\ImageWatcherResident\.folder_icon.ico
> dist\ImageWatcherResident\desktop.ini echo [.ShellClassInfo]
>> dist\ImageWatcherResident\desktop.ini echo IconResource=.folder_icon.ico,0
attrib +s dist\ImageWatcherResident
attrib +h +s dist\ImageWatcherResident\desktop.ini
attrib +h dist\ImageWatcherResident\.folder_icon.ico

echo.
echo Build finished.
echo Resident folder:
echo %cd%\dist\ImageWatcherResident
echo.
echo 請先修改 dist\ImageWatcherResident\config.json，再執行 ImageWatcherResident.exe。
pause
