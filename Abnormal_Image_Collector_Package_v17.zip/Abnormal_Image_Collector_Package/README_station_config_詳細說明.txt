# station_config.json 詳細說明

## 這份檔案的用途
station_config.json 是新版 station_image_collector.py 的主設定檔。

同一支程式可以部署在不同站點，差異都由 station_config.json 控制：
- SPI2
- AOI3
- AOI4
- 3DL
- FT1

正式執行時，程式會讀取同資料夾內的：
  station_config.json

若要部署某站，請先複製對應範例：
  station_config_SPI2_example.json
  station_config_AOI3_example.json
  station_config_AOI4_example.json
  station_config_3DL_example.json
  station_config_FT1_example.json

例如部署 AOI3：
  將 station_config_AOI3_example.json 複製成 station_config.json

然後修改路徑與開關。


## 最常需要修改的欄位
現場部署通常只需要先改這些：

  station
  query_file
  output_root
  log_file
  done_file
  status_file
  run_mode
  single_instance
  max_source_searches_per_scan
  skip_source_search_if_output_exists
  image_groups 裡面的 enabled
  image_groups 裡面的 roots.path

其餘搜尋規則先不要改，除非檔案命名規則不同。


## 最上層欄位說明

### station
站點名稱，會寫入 log，也會出現在輸出檔名與資料夾。

範例：
  "station": "AOI3"


### process_stage
製程階段，用於報表分類。

範例：
  "process_stage": "BEFORE_REFLOW"
  "process_stage": "AFTER_REFLOW"
  "process_stage": "TILT"
  "process_stage": "FINAL_TEST"


### query_file
共同查詢 Excel 路徑。

範例：
  "query_file": "F:/Abnormal_Image_Project_Test/Query_Input/query_list.xlsx"

此 Excel 建議固定欄位：
  Request_ID
  Lot_No
  Unit_No
  Panel_ID
  X
  Y
  Defect_Found_Station
  Defect_Code
  Status
  Owner
  Remark

其中 Unit_No 統一代表 LED NO.。


### query_sheet_name
查詢 Excel 的工作表名稱。

範例：
  "query_sheet_name": "Query_Input"


### output_root
圖片複製後的總輸出資料夾。

範例：
  "output_root": "F:/Abnormal_Image_Project_Test/Output"

目前建議輸出結構：
  Output/{Lot_No}/{Station}/


### log_file
此站點的執行 log CSV。

範例：
  "log_file": "F:/Abnormal_Image_Project_Test/Log/AOI3_collector_log.csv"

log 會記錄：
  Request_ID
  Lot_No
  Unit_No
  Station
  Group_Type
  Variant
  Source_Bucket
  Result
  Source_Image_Path
  Output_Image_Path


### done_file
去重紀錄檔。

範例：
  "done_file": "F:/Abnormal_Image_Project_Test/Log/AOI3_done_record.txt"

用途：
  避免同一張圖片每輪重複複製。

新版會記錄 output path。
下一輪若 output path 不存在，會自動重新補傳。


### status_file
背景常駐狀態檔。

範例：
  "status_file": "F:/Abnormal_Image_Project_Test/Log/AOI3_collector_status.txt"

確認程式是否還在運行時，不要依賴 tasklist/schtasks。
請打開 status_file，看 Timestamp 是否持續更新。


### scan_interval_sec
每一輪掃描間隔秒數。

範例：
  "scan_interval_sec": 300

300 秒 = 5 分鐘。
測試時可先改 60。


### status_heartbeat_sec
常駐等待下一輪時，status_file 更新頻率。

範例：
  "status_heartbeat_sec": 60


### run_mode
執行模式。

測試：
  "run_mode": "once"

正式常駐：
  "run_mode": "loop"

第一次測試一定建議用 once。
確認成功後再改 loop。


### skip_duplicate
是否跳過已複製過且 output path 仍存在的圖片。

建議：
  "skip_duplicate": true

若你想強制每輪都複製，可改 false，但通常不建議。


### dedupe_scope
決定此 group/variant 是以 Lot 還是 Unit 為查詢與去重主題。

可用值：
  "lot"
  "unit"

by lot 範例：
  "dedupe_scope": "lot",
  "required_query_keys": ["Lot_No"]

by unit 範例：
  "dedupe_scope": "unit",
  "required_query_keys": ["Lot_No", "Unit_No"]

若是 by lot，Unit_No 可以空白。
輸出檔名中的 Unit_No 位置會以 LOT 代替，避免同一張整版圖因不同 Unit 重複產生。

若是 by unit，Unit_No 空白時會跳過該 group/variant，log 會記錄：
  SKIP_MISSING_QUERY_KEY


### required_query_keys
執行此 group/variant 必須具備的 query 欄位。

整版圖通常只需要：
  ["Lot_No"]

元件圖通常需要：
  ["Lot_No", "Unit_No"]


### single_instance
是否避免同站點 collector 重複開啟。

建議：
  "single_instance": true

若背景程式已經在跑，又手動再開一次，第二個程式會直接退出。
此功能不依賴 tasklist 或 schtasks，適合公司電腦權限受限的環境。


### lock_file
單一實例鎖定檔。

範例：
  "lock_file": "F:/Abnormal_Image_Project_Test/Log/AOI3_collector.lock"

若已有 lock 且狀態仍新，第二個程式會退出，並寫入：
  AOI3_collector.lock.blocked.txt


### lock_stale_minutes
lock 判定過期時間。

範例：
  "lock_stale_minutes": 30

若前一次程式異常關閉，lock 超過此時間沒有更新，就允許新程式接手。


### max_source_searches_per_scan
每輪最多執行幾次來源資料夾搜尋。

範例：
  "max_source_searches_per_scan": 50

用途：
  避免 query_list.xlsx 長期累積大量 Open 列，造成機台每輪掃描太久。

若設 0 或不設定，代表不限制。

注意：
  已經有 Output 的項目會先被 OUTPUT_EXISTS_SKIP，不會計入這個上限。
  因此即使前面很多 Open 已完成，程式仍會繼續往後掃清單，直到找到尚未完成且需要來源搜尋的項目。
  若達到上限，後面的未完成項目會記錄 SCAN_LIMIT_DEFERRED，下一輪再處理。


### skip_source_search_if_output_exists
若 Output 已有同一查詢主題的有效檔案，是否跳過來源資料夾搜尋。

建議：
  "skip_source_search_if_output_exists": true

判斷條件不是只看 Lot 資料夾是否存在。
程式會檢查檔名是否同時包含：
  Lot_No
  Unit_No
  Station
  Group_Type
  Variant

且檔案不能是 .part，大小也要大於 output_exists_min_size_bytes。

用途：
  避免同一批長清單每輪重複掃描來源大資料夾。


### output_exists_min_size_bytes
Output 預檢的最小有效檔案大小。

範例：
  "output_exists_min_size_bytes": 1024

若檔案太小，可能是空檔或異常檔，不會被視為已完成。


### force_recheck_source
是否強制重新搜尋來源資料夾。

平常：
  "force_recheck_source": false

若懷疑 Output 誤抓或想重新補圖，可暫時改：
  "force_recheck_source": true

此時會忽略 skip_source_search_if_output_exists。


### log_rotate_mb
collector_log.csv 超過指定 MB 時自動封存。

範例：
  "log_rotate_mb": 20

封存後會重新建立新的 collector_log.csv。


### log_archive_dir
log / done_record 封存資料夾。

範例：
  "log_archive_dir": "K:/Log/Archive"


### cleanup_part_files_hours
清理超過指定小時的 .part 暫存檔。

範例：
  "cleanup_part_files_hours": 24

若網路中斷留下 .part，超過此時間會被清除。


### max_done_record_mb
done_record 超過指定 MB 時封存。

範例：
  "max_done_record_mb": 50

注意：
  done_record 封存後，舊資料不再參與 done_record 去重。
  但若 skip_source_search_if_output_exists=true，Output 已存在的圖仍會先被跳過。


## output_layout
控制輸出資料夾與檔名。

建議設定：
  "output_layout": {
    "folder_template": "{Lot_No}/{Station}",
    "filename_template": "{Lot_No}_{Unit_No}_{Station}_{Group_Type}_{Variant}_{Source_Bucket}_{SourceTime}_{OriginalName}"
  }


### folder_template
輸出資料夾格式。

目前建議：
  "{Lot_No}/{Station}"

輸出範例：
  Output/A326689B90903012/AOI3/


### filename_template
輸出檔名格式。

可用變數：
  {Request_ID}
  {Lot_No}
  {Unit_No}
  {Station}
  {Group_Type}
  {Variant}
  {Source_Bucket}
  {SourceTime}
  {OriginalName}

建議保留 OriginalName，方便人工確認是否誤抓。


## image_groups
image_groups 是最重要的區塊。

每一個 group 代表一種資料類型，例如：
  COMPONENT
  BOARD
  HEATMAP
  COMPONENT_2D
  COMPONENT_3D
  DEFECT_MAP

範例：
  "image_groups": [
    {
      "group_type": "COMPONENT",
      "enabled": true,
      ...
    }
  ]


### group_type
資料類型。

範例：
  "group_type": "COMPONENT"
  "group_type": "BOARD"
  "group_type": "HEATMAP"
  "group_type": "DEFECT_MAP"


### enabled
是否啟用此圖種。

只抓元件圖：
  COMPONENT enabled = true
  BOARD enabled = false
  HEATMAP enabled = false

未啟用的 group 不會搜尋，也不會被當成 NOT_FOUND。


### required
目前主要作為報表判讀參考。

範例：
  "required": true

通常：
  元件圖可設 true
  整版圖/熱力圖可設 false


### extensions
允許搜尋的副檔名。

範例：
  "extensions": [".jpg", ".jpeg", ".png", ".bmp"]
  "extensions": [".tif", ".tiff"]


### max_search_depth
搜尋深度限制，避免掃太深太慢。

範例：
  "max_search_depth": 4

若 source root 很大，請務必設定。


## roots
roots 是此 group 或 variant 的來源路徑。

範例：
  "roots": [
    { "bucket": "NG", "path": "F:/Photo/NG", "priority": 1 },
    { "bucket": "OK", "path": "F:/Photo/OK", "priority": 2 }
  ]


### bucket
來源分類，會寫入 log 與輸出檔名。

範例：
  NG
  OK
  COMPONENT
  BOARD
  DEFECT_IMAGE
  MAP
  RAWDATA


### path
來源根目錄。

範例：
  "path": "F:/LED AOI003 Photo"


### priority
搜尋優先順序。

數字越小越先搜尋。

例如 SPI2：
  NG priority = 1
  OK priority = 2


### path_include
只搜尋相對路徑中包含指定字串的資料。

AOI3/AOI4 共用 F:/Map 時很重要。

AOI3：
  "path_include": ["AOI003"]

AOI4：
  "path_include": ["AOI004"]


## folder_match / file_match / match
這三個是搜尋規則。

### folder_match
用來比對資料夾名稱或資料夾路徑。

AOI3 元件圖範例：
  "folder_match": {
    "keys": ["Lot_No"],
    "rule": "contains",
    "scope": "folder_name"
  }

意思：
  圖片所在資料夾名稱必須包含 Lot_No。


### file_match
用來比對檔名。

AOI3 元件圖範例：
  "file_match": {
    "keys": ["Unit_No"],
    "rule": "prefix_before_underscore",
    "scope": "filename"
  }

意思：
  2920_1_UniformLight.jpg 的第一段 2920 必須等於 Unit_No。


### match
通用比對，通常用在不需要分 folder/file 的簡單情境。

範例：
  "match": {
    "keys": ["Lot_No", "Unit_No"],
    "rule": "contains",
    "scope": "relative_path"
  }


## scope
scope 決定要拿哪一段文字來比對。

可用值：
  filename
  stem
  folder_name
  relative_path
  full_path


### filename
只看檔名。

範例：
  2920_1_UniformLight.jpg


### stem
只看不含副檔名的檔名。

範例：
  2920_1_UniformLight


### folder_name
只看圖片所在資料夾名稱。

範例：
  A326689B90902314_194250


### relative_path
看 source root 以下的相對路徑。

範例：
  20260619/A326689B90902314_194250/2920_1_UniformLight.jpg


### full_path
看完整路徑。

通常不建議，除非必要。


## rule
rule 決定如何比對。

### contains
文字包含即可。

適合：
  Lot_No 在資料夾中間
  檔名尾碼判斷


### token_contains
用符號切開後比對 token，較不容易誤抓。

例如：
  2920_1.jpg 會切成 2920、1、jpg


### exact
整段文字完全相等。


### exact_stem
檔名不含副檔名後完全相等。

3DL 2D 元件圖：
  87.tif

若 Unit_No = 87，exact_stem 成立。


### prefix_before_underscore
取檔名第一個底線前的文字比對。

AOI3/AOI4 元件圖：
  2920_1_UniformLight.jpg

比對：
  2920 == Unit_No


### stem_equals_key_plus_suffix
檔名 stem 必須等於 key + suffix。

3DL 3D 元件圖：
  87_3D.tif

設定：
  "keys": ["Unit_No"]
  "suffix": "_3D"

比對：
  87_3D == Unit_No + "_3D"


### fixed_name
固定檔名。

3DL Defect Map：
  DefectMap_Die.jpg

設定：
  "fixed_names": ["DefectMap_Die.jpg"]


### regex
正規表示式。

保留給未來特殊命名使用。


## variants
variants 用於同一 group 底下有多個子類型。

例如 SPI2 HEATMAP：
  H
  AREA
  VOLUME

例如 FT1 BOARD：
  H_DEFECTMAP
  T_YIELDIMAGE

範例：
  "variants": [
    {
      "variant": "H_DEFECTMAP",
      "enabled": true,
      "filename_include": ["_H_DefectMap"]
    }
  ]


### variant
子類型名稱，會寫入 log 與輸出檔名。


### filename_include
檔名必須包含指定字串。

FT1 範例：
  "filename_include": ["_H_DefectMap"]


### filename_exclude
檔名不可包含指定字串。

目前較少用。


## 各站點重點設定

### SPI2
來源：
  F:/Photo/NG
  F:/Photo/OK

主要搜尋：
  Lot_No 在資料夾
  Unit_No 在檔名底線前

建議：
  COMPONENT enabled = true
  BOARD / HEATMAP 視需求 enabled

預設 dedupe_scope：
  COMPONENT = unit
  BOARD = lot
  HEATMAP H / AREA / VOLUME = lot


### AOI3
Before Reflow。

元件圖：
  F:/LED AOI003 Photo
  Lot_No 在資料夾
  Unit_No 在檔名底線前

整版圖：
  F:/Map
  path_include = AOI003
  檔名包含 Lot_No

預設 dedupe_scope：
  COMPONENT = unit
  BOARD = lot


### AOI4
After Reflow。

元件圖：
  F:/LED AOI004 Photo
  Lot_No 在資料夾
  Unit_No 在檔名底線前

整版圖：
  F:/Map
  path_include = AOI004
  檔名包含 Lot_No

預設 dedupe_scope：
  COMPONENT = unit
  BOARD = lot


### 3DL
也就是 Tilt。

來源：
  D:/Defect File

資料類型：
  COMPONENT_2D：87.tif
  COMPONENT_3D：87_3D.tif
  DEFECT_MAP：DefectMap_Die.jpg

注意：
  若沒有 defect，可能沒有 Defect Image 資料夾。
  這不一定是錯誤。

預設 dedupe_scope：
  COMPONENT_2D = unit
  COMPONENT_3D = unit
  DEFECT_MAP = lot


### FT1
只抓整版資料。

來源：
  D:/RawData

主要搜尋：
  Lot_No 在資料夾
  檔名包含 Lot_No
  filename_include 指定尾碼

例如：
  _H_DefectMap
  Mapping_H

預設 dedupe_scope：
  BOARD H_DEFECTMAP = lot
  BOARD Mapping_H = lot


## 建議測試流程
1. 複製某站 example 成 station_config.json。
2. 修改 query_file、output_root、log_file、done_file、status_file。
3. 將 run_mode 設 once。
4. 用 Jupyter 執行 BUILD_STATION_COLLECTOR_WITH_JUPYTER.ipynb。
5. 確認 status_file、log_file、Output 是否正常。
6. 確認後再改 run_mode 為 loop 並打包。


## 常見問題

### 找不到圖
優先檢查：
1. source root 路徑是否正確
2. Lot_No / Unit_No 是否真的出現在資料夾或檔名
3. folder_match / file_match 的 scope 是否選對
4. max_search_depth 是否太小
5. path_include 是否過濾太嚴


### 抓太多圖
優先檢查：
1. rule 是否太寬，例如 contains
2. 是否應改成 prefix_before_underscore 或 token_contains
3. 是否需要加 filename_include
4. 是否需要限制 max_matches


### 已複製後刪掉 Output 圖片，會不會補傳
會。
新版 done_record 會確認 output path 是否仍存在。
若不存在，下一輪會重新複製。


### 背景程式會不會重複開啟多個
新版預設不會。
single_instance=true 時，會使用 lock_file 防止同站點重複執行。


### Output 已經有圖，還會每輪搜尋來源資料夾嗎
若 skip_source_search_if_output_exists=true，通常不會。
程式會先看 Output 是否已有同一 Lot + Unit + Station + Group + Variant 的有效檔案。
若已有，就記錄 OUTPUT_EXISTS_SKIP 並跳過來源搜尋。


### 複製到一半網路斷線
程式會先寫 .part 暫存檔。
完成後才改成正式檔名。
下一輪會重新處理殘留的 .part。
