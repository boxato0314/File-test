﻿@echo off
chcp 65001
cd /d %~dp0

set TASK_NAME=Abnormal_Image_Watcher_SPI
set EXE_PATH=%~dp0ImageWatcher.exe

echo 建立 Windows 排程工作：%TASK_NAME%
echo 執行檔：%EXE_PATH%

schtasks /Create /F /SC MINUTE /MO 5 /TN "%TASK_NAME%" /TR "\"%EXE_PATH%""

echo.
echo 已建立排程工作，每 5 分鐘執行一次。
pause