@echo off
cd /d "%~dp0"

echo Checking process:
tasklist.exe /FI "IMAGENAME eq ImageWatcherResident.exe"

echo.
echo Checking scheduled task:
schtasks.exe /Query /TN "Abnormal_Image_Watcher_Resident_SPI"

echo.
echo If ImageWatcherResident.exe is listed, the watcher is running.
pause
