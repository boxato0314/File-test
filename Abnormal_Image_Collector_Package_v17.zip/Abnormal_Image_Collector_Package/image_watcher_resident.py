import csv
import hashlib
import json
import os
import shutil
import sys
import time
import traceback
from datetime import datetime
from pathlib import Path

try:
    from openpyxl import load_workbook
except Exception as exc:
    raise RuntimeError("This resident watcher only needs openpyxl. Please install openpyxl.") from exc


QUERY_COLUMNS = [
    "Request_ID",
    "Lot_No",
    "Unit_No",
    "Panel_ID",
    "X",
    "Y",
    "Defect_Found_Station",
    "Defect_Code",
    "Status",
    "Owner",
    "Remark",
]


LOG_HEADERS = [
    "Timestamp",
    "Station",
    "Request_ID",
    "Lot_No",
    "Unit_No",
    "Panel_ID",
    "X",
    "Y",
    "Match_Mode",
    "Keywords",
    "Result",
    "Message",
    "Source_Image_Path",
    "Output_Image_Path",
]


def app_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def now_str():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def safe_text(value):
    if value is None:
        return ""
    text = str(value).strip()
    return "" if text.lower() == "nan" else text


def ensure_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)


def load_config():
    config_path = app_dir() / "config.json"
    if not config_path.exists():
        raise FileNotFoundError(f"找不到設定檔: {config_path}")
    with open(config_path, "r", encoding="utf-8-sig") as handle:
        return json.load(handle)


def append_log(log_file, row):
    ensure_dir(Path(log_file).parent)
    exists = Path(log_file).exists()
    with open(log_file, "a", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=LOG_HEADERS)
        if not exists:
            writer.writeheader()
        writer.writerow({key: safe_text(row.get(key, "")) for key in LOG_HEADERS})


def write_status(config, message, extra=None):
    status_file = config.get("status_file") or str(app_dir() / "watcher_status.txt")
    ensure_dir(Path(status_file).parent)
    lines = [
        f"Timestamp={now_str()}",
        f"Station={config.get('station', '')}",
        f"Mode={config.get('run_mode', '')}",
        f"Message={message}",
    ]
    if extra:
        for key, value in extra.items():
            lines.append(f"{key}={safe_text(value)}")
    Path(status_file).write_text("\n".join(lines) + "\n", encoding="utf-8-sig")


def sleep_with_heartbeat(config, interval):
    heartbeat_sec = int(config.get("status_heartbeat_sec", 60))
    heartbeat_sec = max(5, min(heartbeat_sec, interval))
    remaining = interval
    while remaining > 0:
        wait_sec = min(heartbeat_sec, remaining)
        write_status(
            config,
            "SLEEPING",
            {
                "NextScanInSec": remaining,
                "LogFile": config.get("log_file", ""),
            },
        )
        time.sleep(wait_sec)
        remaining -= wait_sec


def read_query_excel(query_file, sheet_name):
    path = Path(query_file)
    if not path.exists():
        raise FileNotFoundError(f"找不到查詢檔: {query_file}")

    workbook = load_workbook(path, data_only=True, read_only=True)
    if sheet_name not in workbook.sheetnames:
        raise ValueError(f"找不到查詢工作表: {sheet_name}")

    sheet = workbook[sheet_name]
    rows = sheet.iter_rows(values_only=True)
    headers = [safe_text(value) for value in next(rows, [])]
    index = {name: pos for pos, name in enumerate(headers)}

    query_rows = []
    for values in rows:
        row = {}
        for column in QUERY_COLUMNS:
            pos = index.get(column)
            row[column] = safe_text(values[pos]) if pos is not None and pos < len(values) else ""
        if any(row.values()):
            query_rows.append(row)
    workbook.close()
    return query_rows


def is_open(row):
    status = safe_text(row.get("Status", "")).lower()
    return status in ["", "open", "new", "待查", "查詢"]


def build_keywords(row, match_mode):
    lot = safe_text(row.get("Lot_No", ""))
    unit = safe_text(row.get("Unit_No", ""))
    panel = safe_text(row.get("Panel_ID", ""))
    x = safe_text(row.get("X", ""))
    y = safe_text(row.get("Y", ""))

    if match_mode == "lot_unit":
        return [lot, unit]
    if match_mode == "lot_panel_xy":
        return [lot, panel, x, y]
    if match_mode == "lot_panel":
        return [lot, panel]
    if match_mode == "lot_only":
        return [lot]
    return [lot, unit]


def file_fingerprint(path):
    item = Path(path)
    raw = f"{item.resolve()}|{item.stat().st_size}|{item.stat().st_mtime}".encode(
        "utf-8",
        errors="ignore",
    )
    return hashlib.md5(raw).hexdigest()


def load_done_record(done_file):
    path = Path(done_file)
    if not path.exists():
        return {}

    done = {}
    for line in path.read_text(encoding="utf-8-sig").splitlines():
        text = line.strip()
        if not text:
            continue
        parts = text.split("\t", 1)
        key = parts[0]
        output_path = parts[1] if len(parts) > 1 else ""
        done[key] = output_path
    return done


def save_done_record(done_file, key, output_path):
    ensure_dir(Path(done_file).parent)
    with open(done_file, "a", encoding="utf-8-sig") as handle:
        handle.write(f"{key}\t{output_path}\n")


def done_output_exists(done, key):
    output_path = done.get(key, "")
    return bool(output_path and Path(output_path).exists())


def searchable_text(source, root, filename, match_scope):
    file_path = Path(root) / filename
    if match_scope == "full_path":
        return str(file_path).lower()
    if match_scope == "relative_path":
        return str(file_path.relative_to(source)).lower()
    if match_scope == "folder_name":
        return Path(root).name.lower()
    return filename.lower()


def find_images(source_root, keywords, extensions, max_depth=None, match_scope="filename"):
    source = Path(source_root)
    if not source.exists():
        raise FileNotFoundError(f"找不到圖片來源資料夾: {source_root}")

    clean_keywords = [keyword.lower() for keyword in keywords if safe_text(keyword)]
    if not clean_keywords:
        return []

    exts = set(ext.lower() for ext in extensions)
    source_depth = len(source.parts)
    results = []

    for root, dirs, files in os.walk(source):
        if max_depth is not None:
            current_depth = len(Path(root).parts) - source_depth
            if current_depth >= int(max_depth):
                dirs[:] = []

        for name in files:
            if Path(name).suffix.lower() not in exts:
                continue
            target_text = searchable_text(source, root, name, match_scope)
            if all(keyword in target_text for keyword in clean_keywords):
                results.append(str(Path(root) / name))
    return results


def copy_images(images, output_root, station, row, done_file, skip_duplicate=True):
    lot = safe_text(row.get("Lot_No", "UNKNOWN_LOT")) or "UNKNOWN_LOT"
    unit = safe_text(row.get("Unit_No", "UNKNOWN_UNIT")) or "UNKNOWN_UNIT"
    request_id = safe_text(row.get("Request_ID", "UNKNOWN_REQUEST")) or "UNKNOWN_REQUEST"
    target_dir = Path(output_root) / lot / request_id / station
    ensure_dir(target_dir)

    done = load_done_record(done_file) if skip_duplicate else set()
    copied = []

    for image in images:
        fingerprint = file_fingerprint(image)
        done_key = f"{request_id}|{station}|{fingerprint}"
        if skip_duplicate and done_output_exists(done, done_key):
            continue

        source = Path(image)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        target = target_dir / f"{lot}_{unit}_{station}_{request_id}_{timestamp}_{source.name}"
        temp_target = target.with_name(target.name + ".part")
        if temp_target.exists():
            temp_target.unlink()

        shutil.copy2(source, temp_target)
        temp_target.replace(target)
        copied.append((str(source), str(target)))

        if skip_duplicate:
            save_done_record(done_file, done_key, str(target))
    return copied


def run_once(config):
    station = config["station"]
    query_file = config["query_file"]
    sheet_name = config.get("query_sheet_name", "Query_Input")
    source_root = config["source_image_root"]
    output_root = config["output_root"]
    log_file = config["log_file"]
    done_file = config.get("done_file", str(app_dir() / "done_record.txt"))
    match_mode = config.get("match_mode", "lot_unit")
    extensions = config.get("image_extensions", [".jpg", ".jpeg", ".png", ".bmp"])
    max_depth = config.get("max_search_depth")
    match_scope = config.get("match_scope", "filename")
    skip_duplicate = bool(config.get("skip_duplicate", True))

    total = 0
    found = 0
    not_found = 0
    copied_count = 0

    for row in read_query_excel(query_file, sheet_name):
        if not is_open(row):
            continue

        total += 1
        request_id = safe_text(row.get("Request_ID", ""))
        lot = safe_text(row.get("Lot_No", ""))
        unit = safe_text(row.get("Unit_No", ""))
        panel = safe_text(row.get("Panel_ID", ""))
        x = safe_text(row.get("X", ""))
        y = safe_text(row.get("Y", ""))
        keywords = build_keywords(row, match_mode)

        base_log = {
            "Timestamp": now_str(),
            "Station": station,
            "Request_ID": request_id,
            "Lot_No": lot,
            "Unit_No": unit,
            "Panel_ID": panel,
            "X": x,
            "Y": y,
            "Match_Mode": match_mode,
            "Keywords": "|".join(keywords),
        }

        try:
            images = find_images(
                source_root,
                keywords,
                extensions,
                max_depth=max_depth,
                match_scope=match_scope,
            )
            if not images:
                not_found += 1
                append_log(log_file, {**base_log, "Result": "NOT_FOUND", "Message": "No matched image."})
                continue

            copied = copy_images(images, output_root, station, row, done_file, skip_duplicate)
            found += 1
            copied_count += len(copied)

            if copied:
                for source, target in copied:
                    append_log(
                        log_file,
                        {
                            **base_log,
                            "Result": "FOUND",
                            "Message": f"Copied 1 image. Total matched={len(images)}",
                            "Source_Image_Path": source,
                            "Output_Image_Path": target,
                        },
                    )
            else:
                append_log(
                    log_file,
                    {
                        **base_log,
                        "Result": "FOUND_DUPLICATE_SKIP",
                        "Message": f"Matched {len(images)} image(s), but already copied before.",
                        "Source_Image_Path": ";".join(images),
                    },
                )
        except Exception as exc:
            append_log(log_file, {**base_log, "Result": "ERROR", "Message": str(exc)})

    summary = {
        "Total": total,
        "Found": found,
        "NotFound": not_found,
        "Copied": copied_count,
        "LogFile": log_file,
    }
    write_status(config, "RUN_ONCE_OK", summary)
    print(f"[{now_str()}] Station={station}, Total={total}, Found={found}, NotFound={not_found}, Copied={copied_count}")


def main():
    config = load_config()
    interval = int(config.get("scan_interval_sec", 300))
    run_mode = config.get("run_mode", "loop").lower()

    print("======================================")
    print(" Abnormal Image Watcher Resident")
    print("======================================")
    print(f"APP DIR : {app_dir()}")
    print(f"STATION : {config.get('station', '')}")
    print(f"MODE    : {run_mode}")
    print("Press Ctrl+C to stop.")
    print("")
    write_status(config, "STARTED", {"AppDir": app_dir()})

    if run_mode == "once":
        run_once(config)
        return

    while True:
        try:
            write_status(config, "LOOP_START", {"LogFile": config.get("log_file", "")})
            run_once(config)
        except Exception:
            error = traceback.format_exc()
            print(error)
            write_status(config, "PROGRAM_ERROR", {"Error": error})
            try:
                append_log(
                    config["log_file"],
                    {
                        "Timestamp": now_str(),
                        "Station": config.get("station", ""),
                        "Result": "PROGRAM_ERROR",
                        "Message": error,
                    },
                )
            except Exception:
                pass
        sleep_with_heartbeat(config, interval)


if __name__ == "__main__":
    main()
