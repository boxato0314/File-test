# AOI Uploader V2.1 Config 詳細說明

## 建議使用方式

### 1. 快速測試
使用 `config_test_fast.ini`：

- 刪除關閉
- Folder 穩定等待 0 分鐘
- 只需 1 次穩定掃描
- Component 每 30 秒掃描
- 每資料夾抽樣 20 張

先測 1 個資料夾，再測 3 個，最後測 28 個。

### 2. 正式量產
使用 `config_production_recommended.ini` 作為起點：

- Component Image 使用 Folder Mode
- 每個約 10,000 張資料夾只建立一筆 SQLite Queue
- 最後寫入停止 20 分鐘
- 連續 2 次檔案數與總容量相同
- 每資料夾抽樣 100 張
- 驗證成功後保留來源 24 小時再刪除
- Completed Queue 保留 7 天

---

## 主要參數解釋

### `global_max_parallel_jobs`
全程式同時傳輸工作數。

建議：

```ini
global_max_parallel_jobs = 2
```

大量小檔案不一定平行越高越快。NAS metadata、SMB latency 或磁碟 IOPS 可能先飽和。

### `robocopy_mt`
單一 Robocopy 工作的多執行緒數。

建議起點：

```ini
robocopy_mt = 16
```

NAS 負載低且網路足夠時，可測 24 或 32。CPU、NAS 或網路壓力過高時，降為 8。

### `folder_scan_depth`
Component Image 工作資料夾所在層級。

```ini
folder_scan_depth = 1
```

表示：

```text
source_path
├─ 工作資料夾01
├─ 工作資料夾02
└─ 工作資料夾03
```

若工作資料夾位於第二層，才改成 2。

### `folder_stable_minutes`
資料夾最後寫入停止多久才可處理。

```ini
folder_stable_minutes = 20
```

避免 AOI 還在寫入時開始搬移。測試可設 0，正式不建議。

### `folder_stable_scan_count`
檔案數、總容量與最大修改時間需連續幾次相同。

```ini
folder_stable_scan_count = 2
```

測試可設 1；正式建議 2。

### `require_complete_flag`
AOI 能產生完成旗標時，最可靠：

```ini
require_complete_flag = true
complete_flag_name = _COMPLETE.flag
```

沒有旗標才使用時間與連續掃描判斷。

### `expected_file_count`
每個資料夾預期約 10,000 張：

```ini
expected_file_count = 10000
```

目前主要用於規劃與提示，不代表一定要剛好 10,000 張。

### `sample_verify_count`
Folder Mode 傳輸後抽樣比對數量：

```ini
sample_verify_count = 100
```

此外仍會比對整個來源與目標的檔案數和總容量。

### `minimum_file_age_days`
只處理超過指定天數的資料：

```ini
minimum_file_age_days = 20
```

正式保留 20 天時不要改。快速測試若檔案是剛建立的，需暫時改成 0。

### `delete_after_verified_minutes`
驗證完成後延後多久刪除：

```ini
delete_after_verified_minutes = 1440
```

1440 分鐘等於 24 小時。第一次測試仍應保持 `[DELETE] enabled = false`。

### `completed_record_retention_days`
已完成 Queue 保留天數：

```ini
completed_record_retention_days = 7
```

Folder Mode 每天約 500～600 筆，7 天很充足。

---

## 28 個資料夾測試較久的原因

28 個資料夾 × 約 10,000 張，相當於約 28 萬張。

程式會進行：

1. 掃描來源資料夾
2. 統計檔案數與總容量
3. Robocopy 傳輸
4. 再次統計來源
5. 統計 NAS 目標
6. 抽樣驗證
7. 更新 SQLite

第一次測試可使用：

```ini
scan_interval_seconds = 30
folder_stable_minutes = 0
folder_stable_scan_count = 1
sample_verify_count = 20
```

確認流程後再恢復正式值。

---

## 狀態判讀

```text
FOLDER:WAITING_STABLE
```

資料夾仍在等待穩定條件。

```text
FOLDER:READY
```

已符合條件，等待 Worker。

```text
FOLDER:TRANSFERRING
```

Robocopy 傳輸中。

```text
FOLDER:VERIFYING
```

正在統計來源、目標及抽樣。

```text
FOLDER:VERIFIED_KEEP
```

驗證完成，因刪除關閉而保留來源。

```text
FOLDER:VERIFIED_PENDING_DELETE
```

驗證完成，等待延後刪除。

```text
FOLDER:DELETED
```

來源工作資料夾已刪除。

---

## 安全要求

- 初次測試必須關閉刪除
- 不使用 `/MOV`、`/MOVE`、`/MIR`、`/PURGE`
- `source_path` 不可設定成 `C:\`、`D:\` 等磁碟根目錄
- 先確認 NAS 權限與目標路徑
- 修改來源或目標路徑後，舊 Queue 不會自動改路徑；測試時需停止程式並 Reset Queue
